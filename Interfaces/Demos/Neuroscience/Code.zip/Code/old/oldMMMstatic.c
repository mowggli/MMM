/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int mmm_static(){
	ATOM* q = initATOM("Is this true?","Question",0);
	//context
	initCONTEXT(q);
	recordNewENTRY(q->context->lexic,"blip","blop");
	recordNewENTRY(q->context->lexic,"flip","flop");
 	//recordNewATOM(q->context->statements, "Sometimes blip flies off.");
 	//recordNewATOM(q->context->statements, "She lies.");
 	//recordNewATOM(q->context->examples, "Le bol.");
	//answers
	q->answers=initATOMS(q->depth+1,"Answers");
	// Yes answer
	recordNewATOM(q->answers, "Yes.");
	ATOM *yes = q->answers->list[q->answers->count-1];
	initCONTEXT(yes);
	// Yes answer statements/reasons
 	recordNewATOM(yes->context->statements, "One reason");

 	recordNewATOM(yes->context->statements, "A second reason.");
	ATOM *result = yes->context->statements->list[yes->context->statements->count-1];
	// Experiment
	initCONTEXT(result);
	recordNewENTRY(result->context->lexic,"efforts","");
	recordNewATOM(result->context->statements, "This is the experiment.");
	ATOM *experiment = result->context->statements->list[result->context->statements->count-1];
	initCONTEXT(experiment);
	recordNewENTRY(experiment->context->lexic,"Experiment","");
	recordNewATOM(experiment->context->statements, "(status) This experiment is over.");

 	recordNewATOM(yes->context->statements, "A third reason.");
	result = yes->context->statements->list[yes->context->statements->count-1];
	// Experiment
	initCONTEXT(result);
	recordNewENTRY(result->context->lexic,"efforts","");
	recordNewATOM(result->context->statements, "This is the experiment.");
	experiment = result->context->statements->list[result->context->statements->count-1];
	initCONTEXT(experiment);
	recordNewENTRY(experiment->context->lexic,"Another Experiment","");
	recordNewATOM(experiment->context->statements, "(OMA) It could fly off. But this is supposed not to happen.");
	recordNewATOM(experiment->context->statements, "(OMA) It could disappear. But this is supposed not to happen.");
	recordNewATOM(experiment->context->statements, "(OMA) We could forget all about it. But this is supposed not to happen.");
	// Yes answer examples
 	recordNewATOM(yes->context->examples, "Un example du sac a dos rouge.");

	// No answer
	recordNewATOM(q->answers, "No.");
	ATOM *non = q->answers->list[q->answers->count-1];
	initCONTEXT(non);
	// No answer statements/reasons
 	recordNewATOM(non->context->statements, "A fourth reason");
 	recordNewATOM(non->context->statements, "A fifth motivation.");
	result = non->context->statements->list[non->context->statements->count-1];
	// Experiment
	initCONTEXT(result);
	recordNewENTRY(result->context->lexic,"efforts","");
	recordNewATOM(result->context->statements, "This is the experiment.");
	experiment = result->context->statements->list[result->context->statements->count-1];
	initCONTEXT(experiment);
	recordNewENTRY(experiment->context->lexic,"Mip-mip","");
	recordNewATOM(experiment->context->statements, "speedy.");

 	recordNewATOM(non->context->examples, "Un example du sac a dos bleu.");
	result = non->context->examples->list[non->context->examples->count-1];
	// Experiment
	initCONTEXT(result);
	recordNewENTRY(result->context->lexic,"efforts","");
	recordNewATOM(result->context->statements, "This is the experiment.");
	experiment = result->context->statements->list[result->context->statements->count-1];
	initCONTEXT(experiment);
	recordNewENTRY(experiment->context->lexic,"Another Experiment","");
	recordNewATOM(experiment->context->statements, "This is the data.");
	recordNewATOM(experiment->context->statements, "This is the meta data.");
	recordNewATOM(experiment->context->statements, "This wa published in this paper: [12].");

 	recordNewATOM(non->context->examples, "Un example du sac a dos VERT.");


	// Other answer
	recordNewATOM(q->answers, "Maybe.");
	ATOM *maybe = q->answers->list[q->answers->count-1];
	initCONTEXT(maybe);
	// No answer statements/reasons
  	recordNewATOM(maybe->context->statements, "A sixth reason.");
	result = maybe->context->statements->list[maybe->context->statements->count-1];
	// Experiment
	initCONTEXT(result);
	//recordNewENTRY(result->context->lexic,"efforts","");
	recordNewATOM(result->context->statements, "This is the experiment.");
	experiment = result->context->statements->list[result->context->statements->count-1];
	initCONTEXT(experiment);
	recordNewENTRY(experiment->context->lexic,"Mip-mip","");
	recordNewATOM(experiment->context->statements, "speedy.");
// 	recordNewATOM(maybe->context->examples, "Un example du sac a dos bleu.");


	/*FILE NAMES*/
	char filename[100];
   //RemoveSpaces(filename);
	strcpy (filename, "./outputs/dummy");
	//strcpy (filenameMU, filename);
   //printf( "File name is: %s \n", filename);
  	FILE *fp = fopen(filename,"w+");

	// Markup
	//strcpy(filename,name);
	strcat(filename,"Markup.txt");
	fp = fopen(filename,"w+"); 
	if( fp ){
		fprintMarkupQUESTION(fp,q);
		printf( "Wrote File %s \n", filename);
	}else{
      printf("Failed to open the file\n");
   }
	fclose(fp);
 
	createFiles("./outputs/dummy",q);
	//ATOM * rq = readQUESTION("markup.txt");
	//freeATOM(rq);
	freeATOM(q);
	return 0;
}
