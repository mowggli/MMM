#include <stdio.h>
#include <string.h>

typedef struct Statement Statement;
//typedef struct Statements Statements;
//typedef struct Context Context;
//typedef struct Question Question;
//typedef struct Examples Examples;
//typedef struct Terms Terms;
//typedef struct Strings Strings;

typedef struct {
	int count;
	char data[50][256];
} Strings;

typedef struct {
   Strings terms;
   Statement* statements;
	int statementscount;
	Strings examples;
}  Context ;

struct Statement{
   char* text;
   Context context;
	Strings examples;
} ;

typedef struct {
	int count;
	Statement* data;
} Statements;


typedef struct {
   char*  text;
   Context context;
   Statements answers;
} Question ;  










/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void printContext(Context context){
	int i;
	printf("Context:\n");
	printf("\tTerms:\n");
	for(i=0;i<context.terms.count;i++){printf("\t\t%s\n",context.terms.data[i]);}
	printf("\tStatements:\n");
	for(i=0;i<context.statementscount;i++){printf("%s\n",context.statements[i].text);}
	//printf("\tExamples:\n");
	for(i=0;i<context.examples.count;i++){printf("\t\t%s\n",context.examples.data[i]);}
}
void printStatement(Statement statement){
	printf("Statement: %s\n",statement.text);
	printContext(statement.context);
}
void printQuestion(Question question){
	printf("Question: %s\n",question.text);
	printContext(question.context);
	int i;
	for(i=0;i<question.answers.count;i++){printStatement(question.answers.data[i]);}
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void printMMMline(int a,int b,char *kind, char *entry)
{
	char I[256];
	strcpy(I,"\n\t");
	int i;
	if(a!=0)
	{
		for(i=0;i<a;i++)
		{
			strcat(I,"\t");
		}
		strcat(I,"|");
	}
	if(b!=0)
	{
		for(i=a;i<b;i++)
		{
			strcat(I,"\t");
		}
		strcat(I,"|");
		strcat(I,I);
		strcat(I,"___");
	}
	strcat(I,kind);
	strcat(I,": ");
	strcat(I,entry);
	printf("%s",I);
}

void fprintMMMline(FILE *fp,int a,int b,char *kind, char *entry)
{
	char I[256];
	strcpy(I,"\n\t");
	int i;
	if(a!=0)
	{
		for(i=0;i<a;i++)
		{
			strcat(I,"\t");
		}
		strcat(I,"|");
	}
	if(b!=0)
	{
		for(i=a;i<b;i++)
		{
			strcat(I,"\t");
		}
		strcat(I,"|");
		strcat(I,I);
		strcat(I,"___");
	}
	strcat(I,kind);
	strcat(I,": ");
	strcat(I,entry);
	fprintf(fp,"%s",I);
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void visualisation(char *QUESTION,char *PRECISION,char *EXPERIMENT,char QTERMS[30][256],char PTERMS[30][256],char ETERMS[30][256],char REASONS[50][256],char OPTIES[50][256],char FALSIES[50][256],char *Status,char *Data,char *Meta,char *Bib,int nR,int nO,int nF,int nQt,int nPt,int nEt,int testED)
{
		int j;
		/*QUESTION*/
		printMMMline(0,0,"Question", QUESTION);
		printMMMline(0,1,"Context", "");
		for(j=0;j<nQt;j++){printMMMline(1,2,"Term",QTERMS[j]);}
		/*ANSWERS*/
		printMMMline(0,1,"Answers", "");
		/*YES*/
		printMMMline(0,2,"Statement", "Yes");
		printMMMline(2,3,"Context", "");
		for(j=0;j<nR;j++){printMMMline(2,4,"Statement", REASONS[j]);}
		/*PRECISION*/
		printMMMline(2,4,"Statement", PRECISION);
		printMMMline(2,5,"Context", "");
		for(j=0;j<nPt;j++){printMMMline(2,6,"Term",PTERMS[j]);	}
		/*EXPERIMENT DESCRITION*/
		if(testED!=0){
			printMMMline(2,6,"Statement (Experiment description)", EXPERIMENT);
			printMMMline(2,7,"Context", "");
			for(j=0;j<nEt;j++){printMMMline(2,8,"Term",ETERMS[j]);		}
			printMMMline(2,8,"Statement", Status);
			printMMMline(2,8,"Statement (Data)", Data);
			printMMMline(2,8,"Statement (Metadata)", Meta);
			printMMMline(2,8,"Statement (Publication)", Bib);
			for(j=0;j<nO;j++){printMMMline(2,8,"Statement (OMA)",OPTIES[j]);}
		}
		/*ANSWER NO*/
		printMMMline(0,2,"Statement", "No.");
		printMMMline(2,3,"Context", "");
		for(j=0;j<nF;j++){printMMMline(2,4,"Statement", FALSIES[j]);}

		/*ANSWER ABSURD*/
		printMMMline(0,2,"Statement", "The question doesn't make sense.");
		printMMMline(0,3,"Context", "");
		printf("\n\n\n");
}

/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void write_visualisation(char *filename,char *QUESTION,char *PRECISION,char *EXPERIMENT,char QTERMS[30][256],char PTERMS[30][256],char ETERMS[30][256],char REASONS[50][256],char OPTIES[50][256],char FALSIES[50][256],char *Status,char *Data,char *Meta,char *Bib,int nR,int nO,int nF,int nQt,int nPt,int nEt,int testED)
{
	char entry[256];
	int j;

   FILE *fp = fopen(filename,"w+"); 
   // If file opened successfully, then write the string to file
   if ( fp )
   {

		/*QUESTION*/
		fprintMMMline(fp,0,0,"Question", QUESTION);
		fprintMMMline(fp,0,1,"Context", "");
		for(j=0;j<nQt;j++){fprintMMMline(fp,1,2,"Term",QTERMS[j]);}

		/*ANSWERS*/
		fprintMMMline(fp,0,1,"Answers", "");

		/*YES*/
		fprintMMMline(fp,0,2,"Statement", "Yes");
		fprintMMMline(fp,2,3,"Context", "");
		for(j=0;j<nR;j++){fprintMMMline(fp,2,4,"Statement", REASONS[j]);}

		/*PRECISION*/
		fprintMMMline(fp,2,4,"Statement", PRECISION);
		fprintMMMline(fp,2,5,"Context", "");
		for(j=0;j<nPt;j++){fprintMMMline(fp,2,6,"Term",PTERMS[j]);	}

		/*EXPERIMENT DESCRITION*/
		if(testED!=0){
			fprintMMMline(fp,2,6,"Statement (Experiment description)", EXPERIMENT);
			fprintMMMline(fp,2,7,"Context", "");
			for(j=0;j<nEt;j++){fprintMMMline(fp,2,8,"Term",ETERMS[j]);		}
			fprintMMMline(fp,2,8,"Statement", Status);
			fprintMMMline(fp,2,8,"Statement (Data)", Data);
			fprintMMMline(fp,2,8,"Statement (Metadata)", Meta);
			fprintMMMline(fp,2,8,"Statement (Publication)", Bib);
			for(j=0;j<nO;j++){fprintMMMline(fp,2,8,"Statement (OMA)",OPTIES[j]);}
		}

		/*ANSWER NO*/
		fprintMMMline(fp,0,2,"Statement", "No.");
		fprintMMMline(fp,2,3,"Context", "");
		for(j=0;j<nF;j++){fprintMMMline(fp,2,4,"Statement", FALSIES[j]);}

		/*ANSWER ABSURD*/
		fprintMMMline(fp,0,2,"Statement", "The question doesn't make sense.");
		fprintMMMline(fp,0,3,"Context", "");
		printf("\n\n\n");
   }
   else
   {
      printf("Failed to open the file\n");
   }

   fclose(fp);
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void visualise_file(char *filename)
{
   char ch;
	FILE *file_pointer = fopen(filename,"r"); 
   if ( file_pointer )
   {
     printf("The contents of %s file are:\n", filename);
     while((ch = fgetc(file_pointer)) != EOF)
       printf("%c", ch);
   }
   else
   {
      printf("Failed to open the file\n\n");
   }

   fclose(file_pointer);
	printf("\n\n");
}

/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void RemoveSpaces(char* source)
{
  char* i = source;
  char* j = source;
  while(*j != 0)
  {
    *i = *j++;
    if(*i != ' '){      i++;}
    else{*i = '-';i++;}
  }
  *i = 0;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void DefineTerms(Strings TERMS)
{
	int i=0;
	char S[256];
	printf("What terms need defining in what you just wrote?\n");
   scanf("%[^\t\n]s",S);getchar();
	while(strcmp(S, "skip")!=0)
	{
   	strcpy (TERMS.data[i],S);
		strcat (TERMS.data[i]," := ");
		scanf("%[^\t\n]s",S);getchar();
    	if(strcmp(S, "skip")*strcmp(S, "")!=0)
		{
   		strcat(TERMS.data[i],S); 
			scanf("%[^\t\n]s",S); getchar();
		}
		i++;
	}
	TERMS.count=i;
}

int DefineTermsOLD(char TERMS[30][256])
{
	int i=0;
	char S[256];
	printf("What terms need defining in what you just wrote?\n");
   scanf("%[^\t\n]s",S);getchar();
	while(strcmp(S, "skip")!=0)
	{
   	strcpy (TERMS[i],S);
		strcat (TERMS[i]," := ");
		scanf("%[^\t\n]s",S);getchar();
    	if(strcmp(S, "skip")*strcmp(S, "")!=0)
		{
   		strcat(TERMS[i],S); 
			scanf("%[^\t\n]s",S); getchar();
		}
		i++;
	}
	return i;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int CollectStatements(char question[256],char STATEMENTS[50][256], char *before,char *after)
{
	int i=0;
	char S[256];
   printf("%s",question);
	scanf("%[^\t\n]s",S);getchar();
	while(strcmp(S, "skip")!=0)
	{
   	strcpy (STATEMENTS[i], before);
		strcat (STATEMENTS[i], S);	
		strcat (STATEMENTS[i], after);	
		i++;
		scanf("%[^\t\n]s",S);getchar();
	}
	return i;
}

void StatementsToContext(char *prompt,Context context, char *before,char *after)
{
	int i=context.statementscount;
	char S[256];
   printf("%s",prompt);
	scanf("%[^\t\n]s",S);getchar();
	while(strcmp(S, "skip")!=0)
	{
   	strcpy (context.statements[i].text, before);
		strcat (context.statements[i].text, S);	
		strcat (context.statements[i].text, after);	
		i++;
		scanf("%[^\t\n]s",S);getchar();
	}
	context.statementscount=i;
}

/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void CollectStatement(char question[256],char S[256])
{
	printf("%s",question);
	scanf("%[^\t\n]s\n",S);
   getchar();
	if(strcmp(S, "skip")==0)
	{
		strcpy (S, "");
	}
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void CollectMandatoryStatement(char question[256],char S[256])
{
	printf("%s",question);
	scanf("%[^\t\n]s\n",S);
   getchar();
	while(strcmp(S, "skip")==0)
	{
		printf("I'm afraid this is one exceptional question that you can't skip answering.\n");	
		scanf("%[^\t\n]s",S);
    	getchar();
   }
}

/************************************************************************************************/
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
int main() {
	Question question;
   int j=0;
	char S[256];
	/*README*/
   strcpy (S, "");
	printf("Hello\nThe only thing you need to know is that at any point, if you feel like not answering you can type 'skip' and then ENTER to move on.\t");
	while(strcmp(S, "skip")!=0){	scanf("%[^\t\n]s",S);getchar();}
	printf("Ok, well done, you got it, we can start...\n\n");	
   /* WORKING ASSUMPTION & QUESTION*/
	CollectMandatoryStatement("What is your working assumption?\n",S);
	strcpy(question.text,"Is this true: '");
	strcat(question.text,S);
	strcat(question.text,"'?");
	/*FILE NAMES*/
   char filename[100];
	char filenameMU[100];
   strcpy (filename, S);
   RemoveSpaces(filename);
	strcpy (filenameMU, filename);
   printf( "File name is: %s \n", filename);
	/* QUESTION CONTEXT */
	DefineTerms(question.context.terms); 
	int nQt=question.context.terms.count;
	/* ANSWERS */
	Statement yes;
	Statement no;
	Statement absurd;
	strcpy(yes.text,"Yes.");
	strcpy(no.text,"No.");
	strcpy(absurd.text,"The question doesn't make sense.");
	question.answers.data[0]=yes;
	question.answers.data[1]=no;
	question.answers.data[2]=absurd;
	question.answers.count=3;
   /* STATE OF THE ART , REASONS */
	char REASONS[50][256]; //yes.context.statements
	//int nR=CollectStatements("What are all the reasons presently supporting your assumption? (state of the art motivations and logical inferences)?\n",REASONS,"","");
	//int nR=CollectStatements("What are all the reasons presently supporting your assumption? (state of the art motivations and logical inferences)?\n",REASONS,"","");
	int nR;
	StatementsToContext("What are all the reasons presently supporting your assumption? (state of the art motivations and logical inferences)?\n",
										(yes.context),"","");
printContext(yes.context);

	/* STATE OF THE ART , REASONS AGAINST */
	char FALSIES[50][256]; // &(question.answers[1].context).statements
   int nF=CollectStatements("Are there any reasons to your present knowledge that might support the fact that your assumption isn't true? (state of the art motivations and logical inferences)?\n",FALSIES,"","");
	/* EXPERIMENT DESCRIPTION */
	char EXPERIMENT[256],OPTIES[50][256],ETERMS[30][256];
	// question.answers[0].context).statements
	char Author[256], Bib[256], Status[256], Data[256], Meta[256];
	printf("Please describe your experiment.\n");
   scanf("%[^\t\n]s\n",EXPERIMENT); getchar();
	int nO,nEt;
	char entry[256];
	strcpy (Bib, "");
	int testED=strcmp(EXPERIMENT, "skip"); printf("S=%s and testED=%d\n",EXPERIMENT,testED);
	if(testED!=0)
	{
		nEt=DefineTermsOLD(ETERMS);
   	CollectStatement("Who is or will be carrying out this experiement?\n",Author);
		printf("Type '0' if this experiment has not yet started, '1' if it has, '2' if it is finished.\n");
		scanf("%d",&j);getchar();
		if(j==0){strcpy (Status, "This experiment is not yet started."); 	}
		else if(j==1){strcpy (Status, "This experiment is currently being carried out by ");strcat (Status, Author);strcat (Status, ".");}
		else if(j==2){
			strcpy (Status, "This experiment is over.");
			CollectStatement("Have you published your results? If so, please enter reference of publication. Otherwise type enter.\n",Bib);
		}
		else 
		{
			printf("Problem. I'm putting 'Status unknown'.\n");
			strcpy (Status, "Unclear");
		}
   	CollectStatement("Please register data of your experiment. /!\\TODO/!\\ \n",Data);
   	CollectStatement("Please register meta data of your experiment./!\\TODO/!\\ \n",Meta);
   	nO=CollectStatements("What could go wrong in your experiment? Please list all possibilities you can think of. \n",OPTIES,""," But this is assumed not to happen.");
		strcpy(OPTIES[nO],"Some unforseen thing could go wrong. But this is assumed not to happen.");
		nO++;
	}

	/* PRECISION */
	char PRECISION[256];	// question.answers[0].context.statements[k];k++
	strcpy(PRECISION,"Efforts are being made to show that '");
	CollectMandatoryStatement("If your experiment works, what will it show that supports your working assumption?\nIt will show that ...",entry);
	strcat(PRECISION,entry);
	strcat(PRECISION,"'.");
	char PTERMS[30][256];
	int nPt=DefineTermsOLD(PTERMS);

   /* VISUALISE */
 	//visualisation(question.text,PRECISION,EXPERIMENT,question.context.terms,PTERMS,ETERMS,REASONS,OPTIES,FALSIES,Status,Data,Meta,Bib,nR,nO,nF,nQt,nPt,nEt,testED);
	//write_visualisation(filename,question.text,PRECISION,EXPERIMENT,question.context.terms,PTERMS,ETERMS,REASONS,OPTIES,FALSIES,Status,Data,Meta,Bib,nR,nO,nF,nQt,nPt,nEt,testED);
	//visualise_file(filename);
	//write_visualisationMU(filenameMU,question.text,PRECISION,EXPERIMENT,question.context.terms,PTERMS,ETERMS,REASONS,OPTIES,FALSIES,Status,Data,Meta,Bib,nR,nO,nF,nt,pnt,ent,testED);
	//visualise_file(filenameMU);
   
   return 0;
}


