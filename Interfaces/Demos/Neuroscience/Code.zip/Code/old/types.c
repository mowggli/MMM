#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
static const char STOP[] = "stop";
#define PROBLEM -1
#define CONTINUE 1
#define ENOUGH 0

/* List of strings*/
typedef struct {
	int count;
	char* name;
	char* type;
	char* list[10];// 10 is the nb of strings
} STRINGS;

/* Term */
typedef struct {
	char expression[1000];
	char definition[1000];
} TERM;

/* Terms */
typedef struct {
	int count;
	TERM *list[10];
} TERMS;

typedef struct something CONTEXT;

/* Statement */
typedef struct {
   char* text;
	char* type;
   CONTEXT *context;
	STRINGS *examples;
} STATEMENT ;

/* List of statements*/
typedef struct {
	int count;
	STATEMENT* list[50];
} STATEMENTS;

/* Question */
typedef struct {
   char*  text;
   CONTEXT *context;
   STATEMENTS *answers;
} QUESTION ;  

/* Context */
struct something {
   TERMS* terms;
   STATEMENTS* statements;
	STRINGS* examples;
}   ;

int promptAndScanText(char *prompt, char *temp){}
/***********************************************STRINGS******************************************/
STRINGS * initSTRINGS(char *name,char *type){}
int collectSTRINGS(char prompt[],STRINGS* strings){}
void printSTRINGS(char *before, char*after,STRINGS* strings){}
void freeSTRINGS(STRINGS* strings){}
int testSTRINGS(){}
/***********************************************TERM*********************************************/
TERM * initTERM(){}
int collectTERM(TERM * term){}
void printTERM(char *before, char*after,TERM* term){}
void freeTERM(TERM* term){}
int testTERM(){}
/************************************************TERMS*******************************************/
TERMS * initTERMS(){}
int collectTERMS(TERMS* terms){}
void printTERMS(char *before, char*after,TERMS* terms){}
void freeTERMS(TERMS* terms){}
int testTERMS(){}
/**********************************************STATEMENT*****************************************/
STATEMENT * initSTATEMENT(char *type){}
int collectSTATEMENT(char prompt[],STATEMENT* statement){}
int collectSTATEMENT_EXAMPLES(char prompt[],STATEMENT* statement){}
void printSTATEMENT(char *before, char*after,STATEMENT* statement){}
void freeSTATEMENT(STATEMENT* statement){}
int testSTATEMENT(){}
/**********************************************STATEMENTS****************************************/
STATEMENTS * initSTATEMENTS(){}
int collectSTATEMENTS(char prompt[],char type[], STATEMENTS* statements){}
void printSTATEMENTS(char *before, char*after,STATEMENTS* statements){}
void freeSTATEMENTS(STATEMENTS* statements){}
int testSTATEMENTS(){}
/************************************************QUESTION****************************************/
QUESTION * initQUESTION(){}
int collectQUESTIONandANSWERS(char prompt[],QUESTION* question){}
void printQUESTION(char *before, char*after,QUESTION* question){}
void printANSWERS(char *before, char*after,QUESTION* question){}
void freeQUESTION(QUESTION* question){}
int testQUESTION(){}
/*************************************************CONTEXT****************************************/
CONTEXT *initCONTEXT(){}
int collectCONTEXT(char prompt[],CONTEXT *context){}
int printCONTEXT(char *before, char*after,CONTEXT *context){}
void freeCONTEXT(CONTEXT *context){}
int testCONTEXT(){}
