#include "tete.h"

/************************************************************************************************/
/*                                                                                              */
/*                                                                                              */
/*                                	   I N T E R F A C E                                        */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
static const char outputfolder[] = "./outputs";
int promptno =1;

char status[]="ZZ";

char defaultPublicationPrompt[] = "\tPlease bibliographic reference (or type enter to skip):\nPUBLICATION ";
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int promptAndScan(char *prompt, char *text){
	printf("%s",prompt);
	int r=scanf("%[^\n]s\n",text);
	getchar();
	if(!r){*text=' ';}
	return r;
}

int promptAndScanInstruction(char *prompt, char *text){
	printf("\t(%d) %s",promptno,prompt);
	int r  = scanf("%[^\n]s\n",text);
	getchar();
	if(!r){
		*text = ' ';
	}
	promptno++;
	return r;
}

int promptAndScanInstructionManditory(char *prompt, char *text){
	printf("\t(%d) %s",promptno,prompt);
	int r = scanf("%[^\n]s\n",text);
	getchar();
	while(!r){
		//printf("\tPlease answer\n");
		r=scanf("%[^\n]s\n",text);
		getchar();
	}
	promptno++;
	return r;
}

char * RemoveSpaces(char source[]){
	static char name[500];
	int len=0;
	int k;
	for(k=0;k<strlen(source);k++){ 
		if(source[k]==' '){
			name[len]='-';
			len ++;
		} else if (ispunct(source[k])>0){ }
		else{
			name[len]=source[k];
			len ++;
		}
	}
	name[len] = '\0';
	return name;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void createFiles(char givenname[], ATOM *q){
	printf("\n----------------------------------------------------------------------------------------------\n");
	int r= mkdir(outputfolder,0777);
	if(errno == EEXIST ){
	} else if(r && errno != EEXIST ){
   	printf("Error while trying to create folder %s! (r=%d) errno = %d\n",outputfolder,r,errno);
	} else{
		printf("Created folder %s\n",outputfolder);
	} 		
	char name[200];
	strcpy(name,RemoveSpaces(givenname));
	//folder
	char folder[200]; errno=0;
	snprintf(folder,200,"%s/%s",outputfolder,name);
	r= mkdir(folder,0777);
	if(errno == EEXIST ){
		printf("Folder %s already exists: overwriting its contents!\n",folder);
	} else if(r && errno != EEXIST ){
   	printf("Error while trying to create folder %s! (r=%d) errno = %d\n",folder,r,errno);
	} else{
		printf("Created folder %s\n",folder);
	} 		
	// Latex
	char filename[200];
	snprintf(filename,200,"%s/%s-Latex.tex",folder,name);
	FILE *fp = fopen(filename,"w+"); 
	if( fp ){
		fprintf(fp,"\\section{%s}\n\n",givenname);
		fprintLatexQUESTION(fp,q);
		fprintf(fp,"\n\n");
		fprintTikzQUESTION(fp,q);
		printf( "Wrote Latex file:\t\t\t %s \n", filename);
	} else 	if(fp == NULL) {
      printf("Error opening file %s! errno = %d\n",filename,errno);   
      exit(1);             
	}
	fclose(fp);
	// Forest
	snprintf(filename,200,"%s/%s-Forest.txt",folder,name);
	fp = fopen(filename,"w+"); 
	if( fp ){
		fprintForestQUESTION(fp,q);
		printf( "Wrote 'tree-like visualisation' file:\t %s \n", filename);
	}
	fclose(fp);
	// Markup
	snprintf(filename,200,"%s/%s-MU.txt",folder,name);
	fp = fopen(filename,"w+"); 
	if( fp ){
		fprintMarkupQUESTION(fp,q);
		printf( "Wrote markup file:\t\t\t %s \n", filename);
	}
	fclose(fp);
	printf("----------------------------------------------------------------------------------------------\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void repeatfprintf(FILE *fp,char *s, int n){
	int i;
	for (i=0;i<n;i++){
		fprintf(fp,"%s",s);
	}
}

void framefprintf(FILE *fp,char *s, int n){
	printf("\t|");
	int i=(n-2-strlen(s))/2;
	repeatfprintf(stdout," ",i);
	printf("%s",s);
	i=n-i-2-strlen(s);
	repeatfprintf(stdout," ",i);
	printf("|\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void getLexic(ATOM *a,char *expression){
	char term[200], definition[200], prompt[200];
	snprintf(prompt,200,"\t(%da) Please list non-obvious terms that you used in %s\t(type enter to skip at any point)\nTERM ",promptno-1,expression);
	//snprintf(prompt,200,"\tLEXIC\n\tTERM ");
	if(promptAndScan(prompt, term)){
		//snprintf(prompt,200,"\tHow do you define '  %s ' ?\t",term);//strcpy(prompt,"How do you define ' ");	strcat(prompt,term);	strcat(prompt," ' ?\t");
		snprintf(prompt,200,"\t:= ");
		if(!promptAndScan(prompt, definition)){
				strcpy(definition,"??");
		}	
		if(!a->context){initCONTEXT(a);}
		recordNewENTRY(a->context->lexic,term,definition);
		//snprintf(prompt,200,"\tWhat other non-obvious terms appear in %s?\t",expression);
		snprintf(prompt,200,"TERM ");
		while(promptAndScan(prompt, term)){
			//snprintf(prompt,200,"\tHow do you define '  %s ' ?\t",term);
			snprintf(prompt,200,"\t:= ");
			if(!promptAndScan(prompt, definition)){
				strcpy(definition,"??");
			}	
			recordNewENTRY(a->context->lexic,term,definition);
			//snprintf(prompt,200,"\tWhat other non-obvious terms appear in %s?\t",expression);
			snprintf(prompt,200,"TERM ");
		}
	}
	printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
	framefprintf(stdout,"",120);
	framefprintf(stdout,"Rather than have the user register her own new definition for each term or leave the definition blank,",120);
	framefprintf(stdout,"here the interface would make suggestions of definitions for her to choose from.",120);
	framefprintf(stdout,"These suggestions would be taken from the definitions previously given by other users for the same term.",120);
	printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
}

void getReference(ATOM *a, char *prompt){	
	char text[2000],publication[2000],altprompt[200];
	snprintf(altprompt,200,"\t(%db) %s",promptno-1,prompt);
	if(promptAndScan(altprompt, publication)){
		strcpy(text,"Published in: ");
		if(!a->context){initCONTEXT(a);}
		strcat(text,publication);
		recordNewATOM(a->context->statements,text);
	}
}

void getReasons(CONTEXT * c, char *instruction, char *subinstruction){
	char text[1000];
	if(promptAndScanInstruction(instruction,text)){ 
		recordNewATOM(c->statements,text);
		getLexic(c->statements->list[c->statements->count-1],"your wording of this reason");
		getReference(c->statements->list[c->statements->count-1], defaultPublicationPrompt);
		promptno = promptno-1;
		while(promptAndScanInstruction(subinstruction,text)){
			recordNewATOM(c->statements,text);
			getLexic(c->statements->list[c->statements->count-1],"your wording of this reason");
			getReference(c->statements->list[c->statements->count-1], defaultPublicationPrompt);
			promptno = promptno-1;
		}
	}
	printNBReason();
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void printNBHypothesis(){
	printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
	framefprintf(stdout,"",120);
	framefprintf(stdout,"Here, the interface would ask the user if her working hypothesis is the same as",120);
	framefprintf(stdout,"similar ones previously recorded in the MMM by other users, assuming any similar ones are found.",120);
	printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
}

void printNBReason(){
	printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
	framefprintf(stdout,"",120);
	framefprintf(stdout,"Here, instead of typing statements expressing the reasons she is prompted to give,",120);
	framefprintf(stdout,"the user could also select statements already registered in the MMM.",120);
	framefprintf(stdout,"If preregistered statements are almost yet not exactly what the user wants to register,",120);
	framefprintf(stdout,"she is given the opportunity to explicit the relationship/difference between",120);
	framefprintf(stdout,"her newly registered statement and preregistered ones.",120);
	printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
}
/************************************************************************************************/
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
char yesReasonsInstruction[] = "What reasons presently supports your working hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be motivations, statements drawn from the state of the art of your field and/or from logical inferences.\nREASON FOR ";
char  noReasonsInstruction[] = "To your present knowledge are there reasons to expect your working hypothesis might not be true?\n\t    Please list one reason at a time.\n\t    Reasons can be negative results, facts or statements drawn from the state of the art of your field and/or from logical inferences, that disagree/oppose/negate your working hypothesis.\nREASON AGAINST ";
char botReasonsInstruction[] = "Are there reasons to expect your working hypothesis might be irrelevant or absurd?\n\t    Please list one reason at a time.\n\t    Reasons can be ambiguity in the wording of the hypothesis, uncertainty in the meaning of certain terms it involves, etc.\nREASON ";

ATOM * neuroscience_mmm_before(){
	// Question -- Please frame your working hypothesis -------------------------------------------
	char question[2000], assumption[2000],text[2000]; 
	promptAndScanInstructionManditory("What is your working hypothesis?\nHYPOTHESIS ", assumption);
	printNBHypothesis();
	snprintf(question,2000,"Is it true that ' %s ' ?",assumption); 
	ATOM* q = initATOM(question,"question",0);
	initCONTEXT(q);
	getLexic(q,"your wording of your working hypothesis"); //add  definitions to help other people understand your research question;
	q->answers=initATOMS(q->depth+1,"answers");
	// Yes answer ---------------------------------------------------------------------------------
	recordNewATOM(q->answers, "Yes.");
	ATOM *yes = q->answers->list[q->answers->count-1];
	initCONTEXT(yes);
	getReasons(yes->context,yesReasonsInstruction,"What reasons presently supports your working hypothesis?\nREASON FOR ");
/*
	if(promptAndScanInstruction(yesReasonsInstruction,text)){ //refer to other studies, state motivations and lay out the reasoning behind the study
		recordNewATOM(yes->context->statements, text);
		getLexic(yes->context->statements->list[yes->context->statements->count-1],"your wording of this reason");
		getReference(yes->context->statements->list[yes->context->statements->count-1], defaultPublicationPrompt);
		promptno = promptno-1;
		while(promptAndScanInstruction("What reasons presently supports your working hypothesis?\nREASON FOR ", text)){
			recordNewATOM(yes->context->statements, text);
			getLexic(yes->context->statements->list[yes->context->statements->count-1],"your wording of this reason");
			getReference(yes->context->statements->list[yes->context->statements->count-1], defaultPublicationPrompt);
			promptno = promptno-1;
		}
	}
	printNBReason();
*/
	// No answer ----------------------------------------------------------------------------------
	recordNewATOM(q->answers, "No.");
	ATOM *no = q->answers->list[q->answers->count-1];
	initCONTEXT(no);
	getReasons(no->context,noReasonsInstruction,"What reasons disagree/oppose/negate your working hypothesis?\nREASON AGAINST ");
/*
	if(promptAndScanInstruction(noReasonsInstruction,text)){
		recordNewATOM(no->context->statements, text);
		getLexic(no->context->statements->list[no->context->statements->count-1],"your wording of this reason");
		getReference(no->context->statements->list[no->context->statements->count-1], defaultPublicationPrompt);
		promptno = promptno-1;
		while(promptAndScanInstruction("What reasons disagree/oppose/negate your working hypothesis?\nREASON AGAINST ", text)){
			recordNewATOM(no->context->statements, text);
			getLexic(no->context->statements->list[no->context->statements->count-1],"your wording of this reason");
			getReference(no->context->statements->list[no->context->statements->count-1], defaultPublicationPrompt);
			promptno = promptno-1;
		}
	}
	printNBReason();*/
	// Absurd answer ------------------------------------------------------------------------------
	recordNewATOM(q->answers, "The question doesn't make sense or is irrelevant.");
	ATOM *absurd = q->answers->list[q->answers->count-1];
	initCONTEXT(absurd);
	getReasons(absurd->context,botReasonsInstruction,"What could make you working hypothesis irrelevant?\nREASON ");
/*
	if(promptAndScanInstruction(botReasonsInstruction,text)){
	//if(promptAndScan("(4) REASONS -> ABSURD?\n", text)){
		recordNewATOM(absurd->context->statements, text);
		getLexic(absurd->context->statements->list[absurd->context->statements->count-1],"your wording of this reason");
		getReference(absurd->context->statements->list[absurd->context->statements->count-1], defaultPublicationPrompt);
		promptno = promptno-1;
		while(promptAndScanInstruction("What could make you working hypothesis irrelevant?\nREASON ", text)){
			recordNewATOM(absurd->context->statements, text);
			getLexic(absurd->context->statements->list[absurd->context->statements->count-1],"your wording of this reason");
			getReference(absurd->context->statements->list[absurd->context->statements->count-1], defaultPublicationPrompt);
			promptno = promptno-1;
		}
	}
	printNBReason();*/
	// Experiment ---------------------------------------------------------------------------------
	int ex = promptAndScanInstruction("Please describe your experiment/study (eg: experiment design and main methods).\nEXPERIMENT ", text);// brief yet sufficient description of the study
	if(!ex){
		strcpy(text,"Missing experiment description.");
	}
	ATOM *experiment = initATOM(text,"Statement",5);
	initCONTEXT(experiment);
	if(ex){
		getLexic(experiment,"your descripion of your experiement");	//detailed explanation of certain jargon, experiment techniques or procedures , by referring to protocol document or other studies
	}

	if(promptAndScanInstruction("What are your results (so far)? Please register/upload your (meta)data and your interpretation of it.\t /!\\TODO/!\\ \nDATA ", text)){
	//if(promptAndScan("(6) RESULTS (META)DATA /!\\TODO/!\\ \t", text)){
		recordNewATOM(experiment->context->statements, text);
	}
	//char status[100];
	int r;
	if(ex){
		// Confounder ------------------------------------------------------------------------------
		while(promptAndScanInstruction("What might confound or undermine your study?\n\t    What could go wrong in your experiment?\n\t    Please list all possibilities you can think of.\nCONFOUNDER/LIMIT ",text)){
			promptAndScanInstructionManditory("Have you addressed this confounder? Have you checked it couldn't go wrong?\n\t    Type 'Y' for Yes and 'N' for No.\nSTATUS ",status);
			if(strcmp(status,"Y")==0){
				strcat(text," But this issue has been addressed.");	
				recordNewATOM(experiment->context->statements, text);
				ATOM *confounder = experiment->context->statements->list[experiment->context->statements->count-1];
				initCONTEXT(confounder);
				int subex = promptAndScanInstruction("*How* have you addressed it? Please describe your experiment.\nEXPERIMENT ",text);
				if(subex){
					recordNewATOM(confounder->context->statements, text);
					ATOM *subexperiment = confounder->context->statements->list[confounder->context->statements->count-1];
					initCONTEXT(subexperiment);
					if(ex){
						getLexic(subexperiment,"your descripion of your experiement");	
					}
				} else{
					recordNewATOM(confounder->context->statements, "Missing experiment description.");
				}
				promptno = promptno-3 ;
			}
			if(strcmp(status,"N")==0){
				strcat(text," But this is assumed not to happen.");	
				recordNewATOM(experiment->context->statements, text);	
				promptno = promptno-2 ;
			}
		}
		promptno++;
		recordNewATOM(experiment->context->statements, "Some unforseen thing could go wrong. But this is assumed not to happen.");
	}
	
	char author[200];
	promptAndScanInstruction("Please name the individual(s), team(s) and/or institution(s) actively involved in performing this study\nAUTHOR ",author);
	//promptAndScan("(9) Author \t", author);
	promptAndScanInstruction("Please type 'F' if this study is finished, 'P' if it has not yet started or if it is work in progress.\nSTATUS ",status);
	while(strcmp(status,"P")!=0 && strcmp(status,"F")!=0){
		promptAndScan("", status);
	}
	char resultdescr[2000];
	if(strcmp(status,"P")==0){
		r=promptAndScanInstruction("If this experiment is successful what will it show that supports your working hypothesis?\nINTERPRETATION/CONCLUSION ",resultdescr);
		if(!r){
			strcpy(text,"Some argument in favour of the answer being yes.");
		}
		else{
			snprintf(text,200,"Efforts are being made to prove that %s : an experiement is currently being carried out by %s.",resultdescr,author);
		}
	}
	if(strcmp(status,"F")==0){
		char success[100];
		promptAndScanInstruction("Have you proven your working hypothesis? Please type 'Y' for yes, and 'N' for no.\nSTATUS ",success);
		while(strcmp(success,"Y")!=0 && strcmp(success,"N")!=0){
			promptAndScan("", success);
		}
		if(strcmp(success,"Y")==0){
			r=promptAndScanInstruction("What is the conclusion of your study supporting your working hypothesis?\nCONCLUSION ", text);
		}
		if(strcmp(success,"N")==0){
			printf("\tThis case has to be dealt with.\n");
		}
	}
	recordNewATOM(yes->context->statements, text); 
	ATOM *result = yes->context->statements->list[yes->context->statements->count-1];
	initCONTEXT(result);
	if(r){
		char prompt[2000];
		getLexic(result,"what you wrote");
		snprintf(prompt,200,"\t(%d) Have you published your results (so far)? If so, enter reference of publication.\nPUBLICATION ",promptno);
		getReference(result->context->statements->list[result->context->statements->count-1], prompt);
	}
	result->context->statements->list[result->context->statements->count] = experiment;
	result->context->statements->count++;	
	return q;

}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
ATOM * neuroscience_mmm_close(){ return NULL;
	// ask for markup file and scan 
	// name
	// frame nb here the user would actually select a MMM unit registered before.
	// or not: start form scratch
	// Ask if WH was successful or not
	// If not, ask if they still believe its true or if smth went wrong or both
	// Ask if they still believe WH makes sense.
	// if success 
	// if failure but still believe
	// if failure but wrong
	// if failure and don't know
	// if absurd
	// create new question. free old one.rename old file.
	/*
char *removeExtension(char* mystr) {
    char *retstr;
    char *lastdot;
    if (mystr == NULL)
         return NULL;
    if ((retstr = malloc (strlen (mystr) + 1)) == NULL)
        return NULL;
    strcpy (retstr, mystr);
    lastdot = strrchr (retstr, '.');
    if (lastdot != NULL)
        *lastdot = '\0';
    return retstr;
}

*/
	// snprintf(othername,200,"%sOld.txt",removeExtension(name)); int rename(name, othername); printf("Renamed file %s to %s\n",othername,name);
	// remove folder names at begin of other name
	// createfiles(othername, newq);
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
ATOM * neuroscience_mmm(){
	// status
	promptAndScanInstruction("Do you want to register a study that is...\n\t    ...not started --> type 'S',\n\t    ...in process --> type 'P',\n\t    ... finished --> type 'F'\nSTATUS ", status);
	while(strcmp(status,"S")!=0 && strcmp(status,"P")!=0 && strcmp(status,"F")!=0){
		promptAndScan("", status);
	}
	printf("\tOk.\n\n\tNow...\n\n");
	if(strcmp(status,"S")==0 || strcmp(status,"P")==0){
		return neuroscience_mmm_before();
	} else if (strcmp(status,"F")==0){
		return neuroscience_mmm_close();
	} 
	return NULL;
}
