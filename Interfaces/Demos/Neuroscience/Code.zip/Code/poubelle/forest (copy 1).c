/*
char *before(char *b,int a,int b)
{
	char string[200];
	static char before[200];
	strcpy(string,"  ");
	int i;
	if(a!=0){
		for(i=0;i<a;i++){
			strcat(string,"\t");
		}
		strcat(string,"|");
	}
	if(b!=0){
		for(i=a;i<b;i++){
			strcat(string,"\t");
		}
		snprintf(before,200,"%s|\n%s|___",string,string);
		//strcat(before,"|");
	}
	return before;
}
*/

char *indentmore(char *small)
{	printf("\nsmall = %s\n",small);
	static char bigger[2000];
	//snprintf(bigger,2000,"%sX|",small);
strcpy(bigger,small);
strcpy(bigger,"X|X|");
printf("\nbigger = %s\n\n",bigger);
	//snprintf(before,2000,"%s\t|\n%s\t|",indent,indent);
	return bigger;
}

/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
char *depth2indent(int depth){
	static char indent[200];
	strcpy(indent,"");
	int d=depth;
	while(d>0){
		strcat(indent,"   ");
		d--;
	}
	return indent;
}

char *depth2branch(int depth){
	static char indent[200];
	strcpy(indent,"    |\n    |");
	int d=depth;
	while(d>0){
		strcat(indent,"___");
		d--;
	}
	return indent;
}

/************************************************************************************************/
/* LEXIC : { 	int depth;	int count;	ENTRY* list[LISTMAX];	}    					               */
/************************************************************************************************/
void fprintLEXIC(FILE *fp, LEXIC* l){
	if(l&&(l->count>0)){
		fprintf(fp,"%s Lexic:\n",depth2indent(l->depth));
		int i;
		for(i=0;i<l->count;i++){
			fprintENTRY(fp, l->list[i]);
		}
	}
}

/*
void fprintLEXICalt(FILE *fp, LEXIC* l){
	if(l&&(l->count>0)){
		fprintf(fp,"%s Lexic:\n",before(1,l->depth));
		//fprintf(fp,"%s Lexic:\n","\t|\t|\n\t|\t|___");
		int i;
		for(i=0;i<l->count;i++){
			fprintf(fp, "%s",before(1,l->list[i]->depth));
			//fprintf(fp, "\n%s","\t|\t\t|\n\t|\t\t|___");
			fprintENTRYalt(fp, l->list[i]);
		}
	}
}*/

void fprintLEXICalt(FILE *fp, LEXIC* l, char *small){
	char bigger[200] ;
	strcpy(bigger,small);
	strcat(bigger,"\t|");
	if(l&&(l->count>0)){
		fprintf(fp,"%s\n%s__Lexic:\n",small,small);
		//fprintf(fp,"%s Lexic:\n","\t|\t|\n\t|\t|___");
		int i;
		for(i=0;i<l->count;i++){
			//fprintf(fp, "%s",bigger);
			//fprintf(fp, "\n%s","\t|\t\t|\n\t|\t\t|___");
			fprintENTRYalt(fp, l->list[i],bigger);
		}
	}
}
/************************************************************************************************/
/* ENTRY : {	int depth;	char *term;		char *definition;	}    					                  */
/************************************************************************************************/
void fprintENTRY(FILE *fp, ENTRY* e){
	fprintf(fp,"%s__%s := %s\n",depth2indent(e->depth),e->term,e->definition);
}

/*
void fprintENTRYalt(FILE *fp, ENTRY* e){
	fprintf(fp,"%s := %s\n",e->term,e->definition);
}
*/

void fprintENTRYalt(FILE *fp, ENTRY* e, char *small){
	fprintf(fp,"%s\n%s__%s := %s\n",small,small,e->term,e->definition);
}
/************************************************************************************************/
/* ATOMS :  {	int depth;	int count;	char* type;		ATOM* list[LISTMAX];	}                    */
/************************************************************************************************/
void fprintATOMS(FILE *fp, ATOMS* a){
	if(a&&(a->count>0)){
		fprintf(fp,"%s %s:\n",depth2indent(a->depth),a->type);
		int i;
		for(i=0;i<a->count;i++){
			//fprintATOMnude(fp, a->list[i]);
			fprintATOM(fp, a->list[i]);
		}
	}
}

/*

void fprintATOMSalt(FILE *fp, ATOMS* a, int start){
	if(a&&(a->count>0)){
		fprintf(fp,"%s %s:\n",before(start,a->depth),a->type);
		//fprintf(fp,"%s %s:\n","\t|\n\t|___",a->type);
		int i;
		for(i=0;i<a->count;i++){
			//fprintATOMnude(fp, a->list[i]);
			fprintATOMalt(fp, a->list[i],start);
		}
	}
}
*/

void fprintATOMSalt(FILE *fp, ATOMS* a, char *small){
	char bigger[200] ;
	strcpy(bigger,small);
	strcat(bigger,"\t|");

	if(a&&(a->count>0)){
		fprintf(fp,"%s\n%s__%s:\n",small,small,a->type);
		//fprintf(fp,"%s %s:\n","\t|\n\t|___",a->type);
		int i;
		for(i=0;i<a->count;i++){
			//fprintATOMnude(fp, a->list[i]);
			fprintATOMalt(fp, a->list[i],bigger);
		}
	}
}

/************************************************************************************************/
/*  CONTEXT : {	int depth;   LEXIC *lexic;  ATOMS* statements;		ATOMS* examples;		}     */
/************************************************************************************************/
void fprintCONTEXT(FILE *fp, CONTEXT* c){
	if(c){
		fprintf(fp,"%s Context:\n",depth2indent(c->depth));
		fprintLEXIC(fp,c->lexic);
		fprintATOMS(fp,c->statements);
		fprintATOMS(fp,c->examples);
	}
}

/*
void fprintCONTEXTalt(FILE *fp, CONTEXT* c, int start){
	if(c){
		fprintf(fp,"%s Context:\n",before(start,c->depth));
		//fprintf(fp,"%s Context:\n","\t|\n\t|___");
		fprintLEXICalt(fp,c->lexic);
		if(c->depth>1){
			fprintATOMSalt(fp,c->statements,start);
			fprintATOMSalt(fp,c->examples,start);
		}
	}
}
*/

void fprintCONTEXTalt(FILE *fp, CONTEXT* c, char *small){
	char bigger[200] ;
	strcpy(bigger,small);
	strcat(bigger,"\t|");

	if(c){
		fprintf(fp,"%s\n%s__Context:\n",small,small);
		fprintLEXICalt(fp,c->lexic,bigger);
		if(c->depth>1){
			fprintATOMSalt(fp,c->statements,bigger);
			fprintATOMSalt(fp,c->examples,bigger);
		}
	}
}

/************************************************************************************************/
/*  ATOM : {	int depth;   char* text;	char * type;   CONTEXT* context;	ATOMS* answers;	}  */
/************************************************************************************************/
/*void fprintQuestionATOM(FILE *fp, ATOM* a, int start){
	//fprintf(fp,"%s %s - %s\n",depth2indent(a->depth),a->type,a->text);
	fprintf(fp,"%s%s %s\n",before(start,a->depth),a->type,a->text);
	fprintCONTEXTalt(fp,a->context,a->depth);
	fprintATOMSalt(fp,a->answers,a->depth);
}*/

void fprintQuestionATOM(FILE *fp, ATOM* a, char *small){
	char bigger[200] ;
	strcpy(bigger,small);
	strcat(bigger,"\t|");

	fprintf(fp,"%s\n%s__%s %s\n",small,small,a->type,a->text);
	fprintCONTEXTalt(fp,a->context,bigger);
	fprintATOMSalt(fp,a->answers,bigger);
}


void fprintATOM(FILE *fp, ATOM* a){
	fprintf(fp,"%s%s %s\n",depth2indent(a->depth),a->type,a->text);
	fprintCONTEXT(fp,a->context);
	fprintATOMS(fp,a->answers);
}

void fprintATOMalt(FILE *fp, ATOM* a, char *small){
	char bigger[200] ;
	strcpy(bigger,small);
	strcat(bigger,"\t|");

	fprintf(fp,"%s\n%s%s__%s\n",small,small,a->type,a->text);
	//fprintf(fp,"%s %s - %s\n","\t\t|\n\t\t|___",a->type,a->text);
	fprintCONTEXTalt(fp,a->context,bigger);
	fprintATOMSalt(fp,a->answers,bigger);
}



/*

void fprintATOMalt(FILE *fp, ATOM* a, int start){
	fprintf(fp,"%s%s %s\n",before(start,a->depth),a->type,a->text);
	//fprintf(fp,"%s %s - %s\n","\t\t|\n\t\t|___",a->type,a->text);
	fprintCONTEXTalt(fp,a->context,0);
	fprintATOMSalt(fp,a->answers,0);
}
void fprintATOMalt(FILE *fp, ATOM* a, int start){
	fprintf(fp,"%s%s %s\n",before(start,a->depth),a->type,a->text);
	//fprintf(fp,"%s %s - %s\n","\t\t|\n\t\t|___",a->type,a->text);
	fprintCONTEXTalt(fp,a->context,0);
	fprintATOMSalt(fp,a->answers,0);
}*/

void fprintATOMnude(FILE *fp, ATOM* a){
	fprintf(fp,"%s * %s\n",depth2indent(a->depth),a->text);
	fprintCONTEXT(fp,a->context);
	fprintATOMS(fp,a->answers);
}

