//typedef struct Statement Statement;
//typedef struct Statements Statements;
typedef struct Context Context;
//typedef struct Question Question;
//typedef struct Examples Examples;
//typedef struct Terms Terms;
//typedef struct Strings Strings;

typedef struct {
	int count;
	char data[50][256];
} Strings;

typedef struct {
   char* text;
   Context *context;
	Strings examples;
} Statement;

typedef struct {
	int count;
	Statement* data;
} Statements;

struct Context {
   Strings terms;
   Statements statements;
	Strings examples;
} ;

typedef struct {
   char*  text;
   Context context;
   Statements answers;
} Question ;  