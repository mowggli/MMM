#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
static const char STOP[] = "";
#define PROBLEM -1
#define CONTINUE 1
#define ENOUGH 0
#define LISTMAX 50
#define MAX 3

/*TODO 
check temp is freed everywhere.
*/

/* List of strings*/
typedef struct {
	int depth;
	int count;
	char* list[];
} STRINGS;

/* Term */
typedef struct {
	int depth;
	char *expression;
	char *definition;
} TERM;

/* Terms */
typedef struct {
	int depth;
	int count;
	TERM * list[LISTMAX];
} TERMS;

typedef struct something CONTEXT;

/* Statement */
typedef struct {
	int depth;
   char* text;
   CONTEXT *context;
	STRINGS *examples;
} STATEMENT ;

/* List of statements*/
typedef struct {
	int depth;
	int count;
	STATEMENT* list[LISTMAX];
} STATEMENTS;

/* Question */
typedef struct {
	int depth;
   char* text;
   CONTEXT *context;
   STATEMENTS *answers;
} QUESTION ;  

/* Context */
struct something {
	int depth;
   TERMS *terms;
   STATEMENTS* statements;
	STATEMENTS* examples;
}   ;



void printFree(char *general,char *special,  uintptr_t p);
void printFreeNB(char *general,char * special, int n,  uintptr_t p);

void printAllocateNB(bool fail, char *general,char * special, int n, uintptr_t p){
	char temp[200];
	if(fail){	fprintf(stderr, "Malloc for %s%s failed!\n",general,special);		}
	else{			printf("ALLO %zu = %s%s%d\n",p,general,special,n);							}
}
void printFreeNB(char *general,char * special, int n,  uintptr_t p){
	printf("FREE %zu = %s%s%d ...\n",p,general,special,n);
}
/************************************************************************************************/
/*                               					general  			                              */
/************************************************************************************************/
int promptAndScanText(char *prompt, char *temp){
	printf("%s",prompt);
	int i=scanf("%[^\n]s\n",temp);
	//printf("scanf=%d\n",i);
	getchar();
	return i;
}
void RemoveSpaces(char* source)
{
  char* i = source;
  char* j = source;
  while(*j != 0){
    *i = *j++;
    if(*i != ' '){      i++;}
    else{*i = '-';i++;}
  }
  *i = 0;
}

void printAllocate(char *type, unsigned int p){
	printf("Allocated %u = %s\n",p,type);
}
void printFree(char *type, unsigned int p){
	printf("Freeing %u = %s ...\n",p,type);
}

void printAllocateSILENT(char *type, unsigned int p){
}
void printFreeSILENT(char *type, unsigned int p){
}

void indentWITHSPACES(int i){
	int j;
	for(j=0;j<i;j++){
		printf("   ");
	}
}

void indentSIMPLE(int i){
	int j;
	for(j=0;j<i;j++){
		printf("\t");
	}
	printf("|___");
}

void indentGEN(int i,int k){
	int j;
	printf("\t");
	if((i>0)&&(i!=k)){
		for(j=0;j<i;j++){
			printf("\t");
		}
		printf("|");
	}
	for(j=i;j<k;j++){
		printf("\t");
	}
	printf("|");
}

void indent(int k){
	indentGEN(0,k);
}
/************************************************************************************************/
/*                                     STATEMENTS                                               */
/************************************************************************************************/

void printSTATEMENTSonly(int k,char *type,STATEMENTS* s){
	char prompt[200];	
	int i;
	for(i=0;i<s->count;i++){
		indentGEN(k,s->depth);
		printf("\n");
		indentGEN(k,s->depth);
		printf("___");
		printf("%s: %s\n",type,s->list[i]->text);
		snprintf(prompt,200,"%s->list[%d]",type,i);
	}
}

void collectSTATEMENTSonly(char *type,STATEMENTS* s, char *prompt){
	s->count = 0;
	char temp[200] ;
	char prompt2[200];
	while(promptAndScanText(prompt,temp)){
		s->list[s->count] = (STATEMENT *) malloc (sizeof(STATEMENT));//TODO
		if (!s->list[s->count] ){
			snprintf(prompt2,200,"Malloc fail %s->list[%d]!\n",type,s->count);
   		fprintf(stderr, prompt2);
		}
		snprintf(prompt2,200,"%s->list[%d]",type,s->count);
		printAllocate(prompt2, (unsigned int) s->list[s->count]);
		s->list[s->count]->depth=s->depth+1;
		s->list[s->count]->text = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt2,200,"%s->list[%d]->text",type,s->count);
		printAllocate(prompt2, (unsigned int) s->list[s->count]->text);
		strcpy(s->list[s->count]->text,temp);
		s->count++;
	}
}

STATEMENTS *initANDcollectSTATEMENTSonly(char *type,char *prompt,int depth){
	char prompt2[200];
	STATEMENTS *s = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt2,200,"%s->statements",type);
	printAllocate(prompt2, (unsigned int) s);
	s->depth=depth;
	collectSTATEMENTSonly(prompt2,s,prompt);
	return s;
}

STATEMENTS *initSTATEMENTS(char *type,int depth){
	char prompt[200];
	STATEMENTS *s = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt,200,"%s->statements",type);
	printAllocate(prompt, (unsigned int) s);
	s->depth=depth;
	return s;
}


/*
int addDummyANSWER(char* type,STATEMENTS *s){ 
	char prompt2[200];
	s->list[s->count] = (STATEMENT *) malloc (sizeof(STATEMENT));//TODO
	if (!s->list[s->count] ){
		snprintf(prompt2,200,"Malloc fail %s->list[%d]!\n",type,s->count);
   	fprintf(stderr, prompt2);
	}
	snprintf(prompt2,200,"%s->list[%d]",type,s->count);
	printAllocate(prompt2, (unsigned int) s->list[s->count]);
	s->list[s->count]->depth=s->depth+1;
	s->list[s->count]->text = (char *) malloc (40); //TODO
	snprintf(prompt2,200,"%s->list[%d]->text",type,s->count);
	printAllocate(prompt2, (unsigned int) s->list[s->count]->text);
	strcpy(s->list[s->count]->text,"Some answer no-one has yet given.");
	s->count++;
	return 0;
}
*/
int addANSWER(char* type,STATEMENTS *s, char* text){ 
	char prompt2[200];
	s->list[s->count] = (STATEMENT *) malloc (sizeof(STATEMENT));//TODO
	if (!s->list[s->count] ){
		snprintf(prompt2,200,"Malloc fail %s->list[%d]!\n",type,s->count);
   	fprintf(stderr, prompt2);
	}
	snprintf(prompt2,200,"%s->list[%d]",type,s->count);
	printAllocate(prompt2, (unsigned int) s->list[s->count]);
	s->list[s->count]->depth=s->depth+1;
	s->list[s->count]->text = (char *) malloc (40); //TODO
	snprintf(prompt2,200,"%s->list[%d]->text",type,s->count);
	printAllocate(prompt2, (unsigned int) s->list[s->count]->text);
	strcpy(s->list[s->count]->text,text);
	s->count++;
	return 0;
}


void freeSTATEMENTSonly(char *type,STATEMENTS *s){
	char prompt[200];
	while(s->count>0){	
		s->count --;
		snprintf(prompt,200,"%s->list[%d]->text",type,s->count);
		printFree(prompt, (unsigned int) s->list[s->countinitSTATEMENTS(char *type,char *prompt,int depth)]->text);
		free(s->list[s->count]->text);
		snprintf(prompt,200,"%s->list[%d]",type,s->count);
		printFree(prompt, (unsigned int) s->list[s->count]);
		free(s->list[s->count]);
	}
	snprintf(prompt,200,"%s",type);
	printFree(prompt, (unsigned int) s);
	free(s);
}
/************************************************************************************************/
/*                               						TERMS      		                              */
/************************************************************************************************/
void printTERMS(int k,TERMS* terms){
	int i;
	for(i=0;i<terms->count;i++){
		indentGEN(k,terms->list[i]->depth);
		printf("\n");
		indentGEN(k,terms->list[i]->depth);
		printf("___");
		printf("TERM:  %s := %s\n",terms->list[i]->expression,terms->list[i]->definition);
	}			
}

void collectTERMS(char *type,TERMS* terms){
	char temp[200] ;
	char prompt[200];
	while( promptAndScanText("Type a term\t",temp) ){
		/* INDIVIDUAL TERM */
		terms->list[terms->count] = (TERM *) malloc (sizeof(TERM));//TODO
		if (!terms->list[terms->count] ){
			snprintf(prompt,200,"Malloc fail %s->list[%d]!\n",type,terms->count);
   		fprintf(stderr, prompt);
		}
		snprintf(prompt,200,"%s->list[%d]",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]);
		terms->list[terms->count]->depth=terms->depth+1;
		terms->list[terms->count]->expression = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt,200,"%s->list[%d]->expression",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]->expression);
		strcpy(terms->list[terms->count]->expression,temp);
		promptAndScanText("Type a definition\t",temp);
		terms->list[terms->count]->definition = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt,200,"%s->list[%d]->definition",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]->definition);
		strcpy(terms->list[terms->count]->definition,temp);
		terms->count++;
	}
}

TERMS* initANDcollectTERMS(char *type, int depth){
	char prompt[200];
	TERMS* terms = (TERMS *) malloc (sizeof(TERMS)); //TODO
	snprintf(prompt,200,"%s->terms",type);
	printAllocate(prompt, (unsigned int) terms);
	terms->depth=depth;
	terms->count = 0;
	collectTERMS(prompt,terms);
	return terms;
}

void freeTERMS(char *type,TERMS* terms){
	char prompt[200];
	while(terms->count>0){	
		terms->count--;		
		snprintf(prompt,200,"%s->list[%d]->definition",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]->definition);
		free(terms->list[terms->count]->definition);
		snprintf(prompt,200,"%s->list[%d]->expression",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]->expression);
		free(terms->list[terms->count]->expression);
		snprintf(prompt,200,"%s->list[%d]",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]);
		free(terms->list[terms->count]);
	}
	snprintf(prompt,200,"%s ",type);
	printFree(prompt,(unsigned int) terms);
	free(terms);
}
/************************************************************************************************/
/*                                    CONTEXT                                                   */
/************************************************************************************************/
void collectSTATEMENTCONTEXT(char *type,STATEMENT *s){
	char prompt[200];
	s->context  =  (CONTEXT *) malloc (sizeof(CONTEXT)); //TODO
	snprintf(prompt,200,"%s->context",type);
	printAllocate(prompt, (unsigned int) s->context);
	s->context->depth=(s->depth)+1;
	/* TERMS */
	s->context->terms = (TERMS *) malloc (sizeof(TERMS)); //TODO
	snprintf(prompt,200,"%s->context->terms",type);
	printAllocate(prompt, (unsigned int) s->context->terms);
	s->context->terms->count = 0;
	s->context->terms->depth=s->depth+1;
	collectTERMS(prompt,s->context->terms);
	/* CONTEXTUAL STATEMENTS */
	s->context->statements = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt,200,"%s->context->statements",type);
	printAllocate(prompt, (unsigned int) s->context->statements);
	s->context->statements->depth=s->context->depth+1;
	collectSTATEMENTSonly(prompt,s->context->statements,"Type a contextual statement\t:\t");
	/* EXAMPLES */
	s->context->examples = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt,200,"%s->context->examples",type);
	printAllocate(prompt, (unsigned int) s->context->examples);
	s->context->examples->depth=s->context->depth+1;
	collectSTATEMENTSonly(prompt,s->context->examples,"Type an example\t:\t");
}

void 	collectQUESTIONCONTEXT(QUESTION *question){
	question->context  =  (CONTEXT *) malloc (sizeof(CONTEXT)); //TODO
	printAllocate("question->context", (unsigned int) question->context);
	question->context->depth=1;
	question->context->terms = initANDcollectTERMS("question->context->terms",1);
	question->context->statements = initANDcollectSTATEMENTSonly("question->context->statements","Type a contextual statement :\t",2);
	question->context->examples = initANDcollectSTATEMENTSonly("question->context->examples","Type an examples :\t",2);
}

void printCONTEXT(int k,char *type, CONTEXT *c){
	indentGEN(k,c->depth);
	printf("\n");	
	indentGEN(k,c->depth);
	printf("___CONTEXT OF %s:\n",type);
	printTERMS(k,c->terms);
	printSTATEMENTSonly(k,"STATEMENT",c->statements); 
	printSTATEMENTSonly(k,"EXAMPLE",c->examples);	
}

void printQUESTIONCONTEXT(char *type, CONTEXT *c){
	indentGEN(0,c->depth);
	printf("\n");	
	indentGEN(0,c->depth);
	printf("___CONTEXT OF %s:\n",type);
	printTERMS(1,c->terms);
	printSTATEMENTSonly(1,"STATEMENT",c->statements); 
	printSTATEMENTSonly(1,"EXAMPLE",c->examples);	
}


void freeSTATEMENTCONTEXT(char *type,STATEMENT *s){
	char prompt[200];
	snprintf(prompt,200,"%s->context->statements",type);
	freeSTATEMENTSonly(prompt,s->context->statements);
	snprintf(prompt,200,"%s->context->examples",type);
	freeSTATEMENTSonly(prompt,s->context->examples);
	snprintf(prompt,200,"%s->context->terms",type);
	freeTERMS(prompt,s->context->terms);
	snprintf(prompt,200,"%s->context",type);
	printFree(prompt, (unsigned int) s->context);
	free(s->context);
}

void freeQUESTIONCONTEXT(char *type,QUESTION *q){
	char prompt[200];
	snprintf(prompt,200,"%s->context->statements",type);
	freeSTATEMENTSonly(prompt,q->context->statements);
	snprintf(prompt,200,"%s->context->examples",type);
	freeSTATEMENTSonly(prompt,q->context->examples);
	snprintf(prompt,200,"%s->context->terms",type);
	freeTERMS(prompt,q->context->terms);
	snprintf(prompt,200,"%s->context",type);
	printFree(prompt, (unsigned int) q->context);
	free(q->context);
}

/************************************************************************************************/
/*                                     STATEMENTS                                               */
/************************************************************************************************/
void printSTATEMENTS(int k,char *type,STATEMENTS* s){
	indent(s->depth);
	printf("\n");
	indent(s->depth);
	printf("___%sS:\n",type);
	int i;
	char prompt[200];	
	for(i=0;i<s->count;i++){
		indent(s->list[i]->depth);
		printf("\n");
		indent(s->list[i]->depth);
		printf("___%s: %s\n",type,s->list[i]->text);
		snprintf(prompt,200,"%s %d",type,i);
		printCONTEXT(k,prompt,s->list[i]->context);
	}
}

void printANSWERS(char *type,STATEMENTS* s){
	indent(s->depth);
	printf("\n");
	indent(s->depth);
	printf("___%sS:\n",type);
	int i;
	char prompt[200];	
	for(i=0;i<s->count-1;i++){
		indent(s->list[i]->depth);
		printf("\n");
		indent(s->list[i]->depth);
		printf("___%s: %s\n",type,s->list[i]->text);
		snprintf(prompt,200,"%s %d",type,i);
		printCONTEXT(2,prompt,s->list[i]->context);
	}
		indent(s->list[i]->depth);
		printf("\n");
		indent(s->list[i]->depth);
		printf("___%s: %s\n",type,s->list[i]->text);
		//snprintf(prompt,200,"%s %d",type,i);
		//printCONTEXT(0,prompt,s->list[i]->context);
}

/************************************************************************************************/
/*                                    QUESTION                                                  */
/************************************************************************************************/
QUESTION *initQUESTION(char *text){
	QUESTION *question = (QUESTION *) malloc (sizeof(QUESTION)) ;
	if (!question ){
   	fprintf(stderr, "Malloc fail in initQUESTION!\n");
		return NULL;   
	}
	printAllocate("question", (unsigned int) question);
	question->text = (char *) malloc(strlen(text) + 1); //TODO
	printAllocate("question->text", (unsigned int) question->text);
	strcpy(question->text,text);
	question->depth=0;
	return question;
}

void freeQUESTION(QUESTION* question){
	printFree("question->text", (unsigned int) question->text);
	printFree("question", (unsigned int) question);
	free(question);
}
/************************************************************************************************/
/*                                      mmm                                                     */
/************************************************************************************************/
int mmm(){
	char temp[200] ;
	char prompt[200];
	char type[200];
	int i;
	promptAndScanText("What is your working assumption?\t",temp);
	if(strcmp(temp,STOP)!=0){

		printf("................................................................INIT\n");	

		/* QUESTION */
		snprintf(prompt,200,"Is this true: '%s' ?",temp);
		QUESTION *question = initQUESTION(prompt);
		/* CONTEXT */
		collectQUESTIONCONTEXT(question);
		/* ANSWERS */
		question->answers = initANDcollectSTATEMENTSonly("question->answers","Type an answer :\t",1);
		/* ANSWER CONTEXT */
		for(i=0;i<question->answers->count;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			collectSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		addANSWER("question->answers", question->answers, "Some answer no-one has yet given.");
//		addDummyANSWER("question->answers", question->answers);
		/**/

		printf("................................................................PRINT\n");

//		indent(question->depth);
		printf("\tQUESTION: %s\n",question->text);
		printQUESTIONCONTEXT("THE QUESTION", question->context);
		printANSWERS("ANSWER",question->answers);

		printf("................................................................FREE\n");

		/* ANSWER CONTEXT */
		for(i=0;i<question->answers->count-1;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			freeSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		/* ANSWERS */
		freeSTATEMENTSonly("question->answers",question->answers);
		/* CONTEXT */
		freeQUESTIONCONTEXT("question",question);
		/* QUESTION */
		freeQUESTION(question);

		return 0;
	}
	return 0;

}
/************************************************************************************************/
/*                                      neuroscience mmm                                        */
/************************************************************************************************/
int neuroscience_mmm(){
	char temp[200] ;
	char prompt[200];
	char type[200];
	int i;
	promptAndScanText("What is your working assumption?\t",temp);
	if(strcmp(temp,STOP)!=0){

		printf("................................................................INIT\n");	

		/* QUESTION */
		snprintf(prompt,200,"Is this true: '%s' ?",temp);
		QUESTION *question = initQUESTION(prompt);
		/* CONTEXT */
		collectQUESTIONCONTEXT(question);
		/* ANSWERS */
		question->answers = initSTATEMENTS("question->answers",1);
		addANSWER("question->answers", question->answers, "Yes.");
		addANSWER("question->answers", question->answers, "No.");
		addANSWER("question->answers", question->answers, "The question does't make sense or is irrelevant.");
		addANSWER("question->answers", question->answers, "Some answer no-one has yet given.");

		/* ANSWER CONTEXTS */
		for(i=0;i<question->answers->count;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			collectSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		/**/

		printf("................................................................PRINT\n");

//		indent(question->depth);
		printf("\tQUESTION: %s\n",question->text);
		printQUESTIONCONTEXT("THE QUESTION", question->context);
		printANSWERS("ANSWER",question->answers);

		printf("................................................................FREE\n");

		/* ANSWER CONTEXT */
		for(i=0;i<question->answers->count-1;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			freeSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		/* ANSWERS */
		freeSTATEMENTSonly("question->answers",question->answers);
		/* CONTEXT */
		freeQUESTIONCONTEXT("question",question);
		/* QUESTION */
		freeQUESTION(question);

		return 0;
	}
	return 0;

}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int main(){
	//return mmm();
	return neuroscience_mmm();
}