#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
static const char STOP[] = "stop";
#define PROBLEM -1
#define CONTINUE 1
#define ENOUGH 0
#define LISTMAX 50
#define MAX 3

/*TODO 
check temp is freed everywhere.
*/

/* List of strings*/
typedef struct {
	int count;
	char* name;
	char* type;
	char* list[];
} STRINGS;

/* Term */
typedef struct {
	char *expression;
	char *definition;
} TERM;

/* Terms */
typedef struct {
	int count;
	TERM * list[LISTMAX];
} TERMS;

typedef struct something CONTEXT;

/* Statement */
typedef struct {
   char* text;
	char* type;
   CONTEXT *context;
	STRINGS *examples;
} STATEMENT ;

/* List of statements*/
typedef struct {
	int count;
	STATEMENT* list[LISTMAX];
} STATEMENTS;

/* Question */
typedef struct {
   char* text;
   CONTEXT *context;
   STATEMENTS *answers;
} QUESTION ;  

/* Context */
struct something {
   TERMS *terms;
   STATEMENTS* statements;
	//STRINGS* examples;
	STATEMENTS* examples;
}   ;

union STATION {
	QUESTION question;
	STATEMENT statement;
};
/************************************************************************************************/
/*                               					general  			                              */
/************************************************************************************************/
int promptAndScanText(char *prompt, char *temp){
	printf("%s",prompt);
	scanf("%[^\n]s\n",temp);
	getchar();
	return 0;
}
void RemoveSpaces(char* source)
{
  char* i = source;
  char* j = source;
  while(*j != 0)
  {
    *i = *j++;
    if(*i != ' '){      i++;}
    else{*i = '-';i++;}
  }
  *i = 0;
}

void printAllocate(char *type, unsigned int p){
	printf("Allocated %u = %s\n",p,type);
}
void printFree(char *type, unsigned int p){
	printf("Freeing %u = %s ...\n",p,type);
}
/************************************************************************************************/
/*                                     STATEMENTS                                               */
/************************************************************************************************/
void printSTATEMENTS(char *before,char *type,STATEMENTS* s){
	printf("%s\t%ss\n",before,type);
	int i;
	char prompt[200];	
	for(i=0;i<s->count;i++){
		printf("%s\t%s[%d] = %s\n",before,type,i,s->list[i]->text);
		snprintf(prompt,200,"%s[%d]",type,i);
		//printf("%s\t\tCONTEXT for %s:\n",before,prompt);
		printCONTEXT(before,prompt,s->list[i]->context);
	}
}

void printSTATEMENTSonly(char *before,char *type,STATEMENTS* s){
	//printf("%s\t%ss\n",before,type);
	char prompt[200];	
	int i;
	for(i=0;i<s->count;i++){
		printf("%s\t%s[%d] = %s\n",before,type,i,s->list[i]->text);
		snprintf(prompt,200,"%s->list[%d]",type,i);
	}
}


void collectSTATEMENTS(char *type,STATEMENTS* s, char *prompt){
	s->count = 0;
	char temp[200] ;
	char prompt2[200];
	while(s->count<MAX){
		/* INDIVIDUAL ANSWER */
		s->list[s->count] = (STATEMENT *) malloc (sizeof(STATEMENT));//TODO
		if (!s->list[s->count] ){
			snprintf(prompt2,200,"Malloc fail %s->list[%d]!\n",type,s->count);
   		fprintf(stderr, prompt2);
		}
		snprintf(prompt2,200,"%s->list[%d]",type,s->count);
		printAllocate(prompt2, (unsigned int) s->list[s->count]);
		promptAndScanText(prompt,temp);
		s->list[s->count]->text = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt2,200,"%s->list[%d]->text",type,s->count);
		printAllocate(prompt2, (unsigned int) s->list[s->count]->text);
		strcpy(s->list[s->count]->text,temp);
		s->count++;
	}
}

void freeSTATEMENTS(char *type,STATEMENTS *s){
	char prompt[200];
	while(s->count>0){	
		s->count --;
		snprintf(prompt,200,"%s->list[%d]->text",type,s->count);
		printFree(prompt, (unsigned int) s->list[s->count]->text);
		free(s->list[s->count]->text);
		snprintf(prompt,200,"%s->list[%d]",type,s->count);
		printFree(prompt, (unsigned int) s->list[s->count]);
		free(s->list[s->count]);
	}
	snprintf(prompt,200,"%s",type);
	printFree(prompt, (unsigned int) s);
	free(s);

}
/************************************************************************************************/
/*                               					TERM  			                                 */
/************************************************************************************************/
/************************************************************************************************/
/*                               						TERMS      		                              */
/************************************************************************************************/
void printTERMS(char *before,TERMS* terms){
	int i;
	//printf("%s\tTERMS:\n",before);
	for(i=0;i<terms->count;i++){
		printf("%s\tTERM[%d] %s := %s\n",before,i,terms->list[i]->expression,terms->list[i]->definition);
	}			
}

void collectTERMS(char *type,TERMS* terms){
	char temp[200] ;
	char prompt[200];
	while(terms->count<MAX){
		/* INDIVIDUAL TERM */
		terms->list[terms->count]= (TERM *) malloc (sizeof(TERM));//TODO
		if (!terms->list[terms->count] ){
			snprintf(prompt,200,"Malloc fail %s->list[%d]!\n",type,terms->count);
   		fprintf(stderr, prompt);
		}
		snprintf(prompt,200,"%s->list[%d]",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]);
		promptAndScanText("Type a term\t",temp);
		terms->list[terms->count]->expression = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt,200,"%s->list[%d]->expression",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]->expression);
		strcpy(terms->list[terms->count]->expression,temp);
		promptAndScanText("Type a definition\t",temp);
		terms->list[terms->count]->definition = (char *) malloc (strlen(temp) + 1); //TODO
		snprintf(prompt,200,"%s->list[%d]->definition",type,terms->count);
		printAllocate(prompt, (unsigned int) terms->list[terms->count]->definition);
		strcpy(terms->list[terms->count]->definition,temp);
		terms->count++;
	}
}

TERMS* initANDcollectTERMS(char *type){
	char prompt[200];
	TERMS* terms = (TERMS *) malloc (sizeof(TERMS)); //TODO
	snprintf(prompt,200,"%s->terms",type);
	printAllocate(prompt, (unsigned int) terms);
	terms->count = 0;
	collectTERMS(prompt,terms);
	return terms;
}

void freeTERMS(char *type,TERMS* terms){
	char prompt[200];
	while(terms->count>0){	
		terms->count--;		
		snprintf(prompt,200,"%s->list[%d]->definition",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]->definition);
		free(terms->list[terms->count]->definition);
		snprintf(prompt,200,"%s->list[%d]->expression",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]->expression);
		free(terms->list[terms->count]->expression);
		snprintf(prompt,200,"%s->list[%d]",type,terms->count);
		printFree(prompt, (unsigned int) terms->list[terms->count]);
		free(terms->list[terms->count]);
	}
	snprintf(prompt,200,"%s ",type);
	printFree(prompt,(unsigned int) terms);
	free(terms);

}
/************************************************************************************************/
/*                                    CONTEXT                                                   */
/************************************************************************************************/
void collectSTATEMENTCONTEXT(char *type,STATEMENT *s){
	char prompt[200];
	s->context  =  (CONTEXT *) malloc (sizeof(CONTEXT)); //TODO
	snprintf(prompt,200,"%s->context",type);
	printAllocate(prompt, (unsigned int) s->context);
	/* TERMS */
	s->context->terms = (TERMS *) malloc (sizeof(TERMS)); //TODO
	snprintf(prompt,200,"%s->context->terms",type);
	printAllocate(prompt, (unsigned int) s->context->terms);
	s->context->terms->count = 0;
	collectTERMS(prompt,s->context->terms);
	/* CONTEXTUAL STATEMENTS */
	s->context->statements = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt,200,"%s->context->statements",type);
	printAllocate(prompt, (unsigned int) s->context->statements);
	collectSTATEMENTS(prompt,s->context->statements,"Type a contextual statement\t:\t");
	/* EXAMPLES */
	s->context->examples = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
	snprintf(prompt,200,"%s->context->examples",type);
	printAllocate(prompt, (unsigned int) s->context->examples);
	collectSTATEMENTS(prompt,s->context->examples,"Type an example\t:\t");
}

void printCONTEXT(char *before,char *type, CONTEXT *c){
	printf("%s\tCONTEXT OF %s:\n",before,type);
	printTERMS("",c->terms);
	printSTATEMENTSonly("","STATEMENT",c->statements); 
	printSTATEMENTSonly("","EXAMPLE",c->examples);	
}

void freeSTATEMENTCONTEXT(char *type,STATEMENT *s){
	char prompt[200];
	snprintf(prompt,200,"%s->context->statements",type);
	freeSTATEMENTS(prompt,s->context->statements);
	snprintf(prompt,200,"%s->context->examples",type);
	freeSTATEMENTS(prompt,s->context->examples);
	snprintf(prompt,200,"%s->context->terms",type);
	freeTERMS(prompt,s->context->terms);
	snprintf(prompt,200,"%s->context",type);
	printFree(prompt, (unsigned int) s->context);
	free(s->context);
}

void freeQUESTIONCONTEXT(char *type,QUESTION *q){
	char prompt[200];
	snprintf(prompt,200,"%s->context->statements",type);
	freeSTATEMENTS(prompt,q->context->statements);
	snprintf(prompt,200,"%s->context->examples",type);
	freeSTATEMENTS(prompt,q->context->examples);
	snprintf(prompt,200,"%s->context->terms",type);
	freeTERMS(prompt,q->context->terms);
	snprintf(prompt,200,"%s->context",type);
	printFree(prompt, (unsigned int) q->context);
	free(q->context);
}


/************************************************************************************************/
/*                                    QUESTION                                                  */
/************************************************************************************************/


/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int mmm(){
	char temp[200] ;
	char prompt[200];
	char type[200];
	int i;
	promptAndScanText("What is your working assumption?\t",temp);
	if(strcmp(temp,STOP)!=0){
		printf("................................................................INIT\n");	
		QUESTION *question = (QUESTION *) malloc (sizeof(QUESTION)) ;
		if (!question ){
   		fprintf(stderr, "Malloc fail in initQUESTION!\n");
			return PROBLEM;   
		}
		printAllocate("question", (unsigned int) question);
		question->text = (char *) malloc(strlen(temp) + 20); //TODO
		printAllocate("question->text", (unsigned int) question->text);
		snprintf(question->text,200,"Is this true: '%s' ?",temp);
		/* CONTEXT */
		question->context  =  (CONTEXT *) malloc (sizeof(CONTEXT)); //TODO
		printAllocate("question->context", (unsigned int) question->context);
		/* TERMS */
/*		question->context->terms = (TERMS *) malloc (sizeof(TERMS)); //TODO
		printAllocate("question->context->terms", (unsigned int) question->context->terms);
		question->context->terms->count = 0;
		collectTERMS("question->context->terms",question->context->terms);
*/
		question->context->terms = initANDcollectTERMS("question->context->terms");
		/* CONTEXTUAL STATEMENTS */
		question->context->statements = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
		printAllocate("question->context->statements", (unsigned int) question->context->statements);
		collectSTATEMENTS("question->context->statements",question->context->statements,"Type a contextual statement\t:\t");
		/* EXAMPLES */
		question->context->examples = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
		printAllocate("question->context->examples", (unsigned int) question->context->examples);
		collectSTATEMENTS("question->context->examples",question->context->examples,"Type an example\t:\t");
		/* ANSWERS */
		question->answers = (STATEMENTS *) malloc (sizeof(STATEMENTS));//TODO
		printAllocate("question->answers", (unsigned int) question->answers);
		collectSTATEMENTS("question->answers",question->answers,"Type an answer\t:\t");
		/* ANSWER CONTEXT */
		for(i=0;i<question->answers->count;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			collectSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		printf("................................................................PRINT\n");
		printf("QUESTION %s\n",question->text);
		printCONTEXT("","the question", question->context);
		printSTATEMENTS("","ANSWER",question->answers);
		printf("................................................................FREE\n");
		for(i=0;i<question->answers->count;i++){
			snprintf(type,200,"question->answers->list[%d]",i);
			freeSTATEMENTCONTEXT(type,question->answers->list[i]);
		}
		freeSTATEMENTS("question->answers",question->answers);
		freeQUESTIONCONTEXT("question",question);
		printFree("question->text", (unsigned int) question->text);
		printFree("question", (unsigned int) question);
		free(question);
		return ENOUGH;
	}
	return ENOUGH;

}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
int main()
{
	//return testSTRINGS();
	//return testTERM();
	//return testTERMS();
	//return testSTATEMENT();
	//return testSTATEMENTS();
	//return testQUESTION();
	//return testCONTEXT();
	return mmm();


}