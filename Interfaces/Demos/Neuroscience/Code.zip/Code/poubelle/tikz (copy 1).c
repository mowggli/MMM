/*

*/


#include "tete.h"
int entryNo = 0;
int statementNo = 0;
int answerNo = 0;
int answerX=0;
int exampleNo = 0;

void fprintfRepeat(FILE *fp, char *c, int i){
	int j;
	for(j=0;j<i;j++){
		fprintf(fp, "%s",c);
	}
}

void fprintfCommentedTitle(FILE *fp, char *title){
	int l=strlen(title);
	int whites=(80-l-4)/2;
	fprintfRepeat(fp,"\%",80);
	fprintf(fp,"\n");
	fprintfRepeat(fp,"\%",2);
	fprintfRepeat(fp," ",whites);
	fprintf(fp,"%s",title);
	fprintfRepeat(fp," ",whites);
	fprintfRepeat(fp,"\%",2);
	fprintf(fp,"\n");
	fprintfRepeat(fp,"\%",80);
	fprintf(fp,"\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/

void fprintTikzBegin(FILE *fp,ATOM *q){
	fprintf(fp,"\\begin{center}\n");
	fprintf(fp,"\t\\fbox{\\begin{tikzpicture}[scale=0.5,\n");
	fprintf(fp,"\t\t%s/.style={diamond,draw,fill=orange,text width=2cm,align=center,inner sep=0},\n",q->type);
	fprintf(fp,"\t\tPoint/.style={circle,inner sep=0pt,minimum size=5pt,fill=black,draw},\n");
	fprintf(fp,"\t\tAnd/.style={circle,draw,fill=gray},\n");
	fprintf(fp,"\t\tEntry/.style={ellipse,draw,fill=blue!30,align=center,inner sep=2},\n");
	fprintf(fp,"\t\tExample/.style={rectangle, draw,align=center,inner sep=2},\n");
	fprintf(fp,"\t\tAnswer/.style={rectangle,draw,fill=yellow,align=center,inner sep=3},\n");
	fprintf(fp,"\t\tStatement/.style={rectangle,draw,fill=yellow,align=center,inner sep=3}]\n");
	fprintf(fp,"\t\\tikzset{forexample/.style={->,>={Turned Square[open,length=0.3cm]},orange}}\n");
}

void fprintTikzEnd(FILE *fp){
	fprintf(fp,"\\end{tikzpicture}}\end{center}\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void fprintTikzQUESTION(FILE *fp,ATOM* q){
	answerX=-q->answers->count;
	fprintTikzBegin(fp,q);
	fprintfCommentedTitle(fp, "QUESTION");
	fprintf(fp,"\\path (0,0) node [%s] (%s) {%s};\n",q->type,q->type,q->text);
	fprintf(fp,"\\path (%sNode.south)+(0,-2) node [Point] (BRANCH) {};\n",q->type);
	fprintf(fp,"\\draw (%sNode) -- (BRANCH);\n",q->type);
	fprintfRepeat(fp,"\%",80);
	fprintf(fp,"\n");
	fprintf(fp,"\\path ($(%sNode.south)!.3!(BRANCH.north) $) node [Point,fill=orange] (%sContext) {};\n",q->type,q->type);
	fprintfTikzCONTEXT(fp,q->context, "QUESTION","START");
	int i;
	char answernode[200];
	fprintfCommentedTitle(fp, " ANSWERS");
	for(i=0;i<q->answers->count;i++){
		snprintf(answernode,200,"ANSWER%d",answerNo);
		fprintfTikzANSWER(fp, q->answers->list[i]);
	}
	fprintfTikzANSWER(fp,q);
	fprintTikzEnd(fp);
}
void fprintfTikzANSWER(FILE* fp, ATOM *a){
	char node[200];
	snprintf(node,200,"ANSWER%d",answerNo);
	char answerand[200];
	snprintf(answerand,200,"ANSWER%dAND",answerNo);
	char answercontext[200];
	snprintf(answercontext,200,"ANSWER%dCONTEXT",answerNo);

	fprintf(fp,"\\draw (BRANCH) -- ++(%d,-3) node (%s) [%s] {%s};\n",answerX,node,a->type,a->text);

	fprintf(fp,"\\path ($(BRANCH)!0.7!(%s)$) node [Point,fill=yellow] (%s) {};\n",node,answercontext);
	fprintf(fp,"\\draw (%s) -- ++(-1,0) node (%s) [And] {$\\wedge$};\n",answercontext,answerand);

	fprintfTikzCONTEXT(fp,a->context,node,answerand);
	answerNo++;			
	answerX=answerX+2;
}

void fprintfTikzATOM(FILE* fp, ATOM *a, char *node,char *branch){
	//char label[200];
	//snprintf(label,200,"%s",n,e->term);
	//strcpy(label, type);	
	fprintf(fp,"\\draw (%s) -- ++(-1,-3) node (%s) [%s] {%s};\n",branch,node,a->type,a->text);
	fprintfTikzCONTEXT(fp,a->context,node,branch);
	//statementNo++;			
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void fprintfTikzCONTEXT(FILE *fp, CONTEXT* c, char *node,char *branch){
	fprintfCommentedTitle(fp, " CONTEXT");
	char contextnode[200];
	snprintf(contextnode,200,"%sCONTEXT",node);
	char andnode[200];
	snprintf(andnode,200,"%sAND",node);
	fprintf(fp,"\\path ($(%s)!0.7!(%s)$) node [Point,fill=yellow] (%s) {};\n",branch,node,contextnode);
	fprintf(fp,"\\draw (%s) -- ++(-1,0) node (%s) [And] {$\\wedge$};\n",contextnode,andnode);
	//fprintfTikzLEXIC(fp,c->lexic,andnode,branch);
	int i;
	char entrynode[200];
	for(i=0;i<c->lexic->count;i++){
		snprintf(entrynode,200,"ENTRY%d",entryNo);
		fprintfTikzENTRY(fp, c->lexic->list[i], entrynode,andnode);
		entryNo++;	
	}
	char statementnode[200];
	for(i=0;i<c->statements->count;i++){
		snprintf(statementnode,200,"STATEMENT%d",statementNo);
		fprintfTikzATOM(fp, c->statements->list[i], statementnode,andnode);
		statementNo++;	
	}
	char examplenode[200];
	for(i=0;i<c->examples->count;i++){
		snprintf(examplenode,200,"EXAMPLE%d",exampleNo);
		fprintfTikzATOM(fp, c->examples->list[i], examplenode,andnode);
		exampleNo++;	
	}
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void fprintfTikzENTRY(FILE *fp, ENTRY* e,  char *node,char *branch){
	//fprintf(fp,"\\draw (%s) -- ++(2,1) node (%s) [anchor=south west,Entry,text width=1cm] {%s:=%s};\n",branch,node,e->term,e->definition);
	fprintf(fp,"\\node (%s) -- ++(2,1) node (%s) [anchor=south west,Entry,text width=1cm] {%s:=%s};\n",branch,node,e->term,e->definition);
}




/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/

/*
void fprintTikzQUESTION(FILE *fp,ATOM* q){
	answerX=-q->answers->count;

	fprintTikzBegin(fp,q);

	fprintfCommentedTitle(fp, "QUESTION");
	fprintf(fp,"\\path (0,0) node [%s] (%sNode) {%s};\n",q->type,q->type,q->text);
	fprintf(fp,"\\path (%sNode.south)+(0,-2) node [Point] (BRANCH) {};\n",q->type);
	fprintf(fp,"\\draw (%sNode) -- (BRANCH);\n",q->type);
	fprintfRepeat(fp,"\%",80);
	fprintf(fp,"\n");
	fprintf(fp,"\\path ($(%sNode.south)!.3!(BRANCH.north) $) node [Point,fill=orange] (%sContext) {};\n",q->type,q->type);
	fprintf(fp,"\\draw (%sContext) -- ++(1,0) node (%sAnd) [and] {$\\wedge$};\n",q->type,q->type);
	fprintfCommentedTitle(fp, " CONTEXT");
//%\draw (%sNodeAND) -- ++(3,1) node (TERM) [anchor=south west,term, text width=5cm] {Thought  := text written by a person when asked ``What are you thinking of right now?''};
	fprintf(fp,"\\draw (%sAnd) -- ++(2,1) node (a) [anchor=south west,term,text width=1cm] {a};\n",q->type);
	fprintf(fp,"\\draw (%sAnd) -- ++(2,-1) node (b) [anchor=north west,term,text width=1cm] {b};\n",q->type);

	fprintfCommentedTitle(fp, " ANSWERS");
	int i;
	for(i=0;i<q->answers->count;i++){
		fprintfTikzANSWER(fp, q->answers->list[i]);
	}

	fprintfCommentedTitle(fp, " REASONS");
	fprintf(fp,"\\draw (ANSWER%d) -- ++(-1,0.5) node (c) [anchor=south east,term,text width=1cm] {c};\n",0);
	fprintf(fp,"\\draw (ANSWER%dAND) -- ++(-1.5,0) node (d) [anchor=east,term,text width=1cm] {d};\n",0);
	fprintf(fp,"\\draw (ANSWER%dAND) -- ++(-1,-0.5) node (e) [anchor=north east,answer,text width=1cm] {e};\n",0);

	
}
*/
/*

void fprintTikzCONTEXT(FILE* fp, CONTEXT *c, char *indent){
	if(c){
		char indentt[200];
		strcpy(indentt,indent);
		strcat(indentt,"\t");
		fprintf(fp,"\n%s\\%s{}{",indent,c->type);
		fprintTikzLEXIC(fp,c->lexic,indentt);
		fprintTikzATOMS(fp,c->statements,indentt);
		fprintTikzATOMS(fp,c->examples,indentt);
		fprintf(fp,"\n%s}",indent);	
	}
}

void fprintTikzLEXIC(FILE* fp, LEXIC *l, char *indent){
	if(l){
		int i;
		for(i=0;i<l->count;i++){
			fprintf(fp,"\n%s\\%s{%s}{%s}",indent,l->list[i]->type,l->list[i]->term,l->list[i]->definition);
		}
	}
}




void fprintTikzATOMS(FILE* fp, ATOMS *a, char *indent){
	if(a){
		char indentt[200];
		strcpy(indentt,indent);
		strcat(indentt,"\t");
		int i;
		for(i=0;i<a->count;i++){
			//fprintf(fp,"\n%s\\%s{%s}{",indent,a->list[i]->type, a->list[i]->text);
			if(a->list[i]->context){


				fprintTikzCONTEXT(fp,a->list[i]->context,indentt);
				fprintf(fp,"\n%s",indent);
			}		
			fprintf(fp,"}");
		}
	}
}
*/