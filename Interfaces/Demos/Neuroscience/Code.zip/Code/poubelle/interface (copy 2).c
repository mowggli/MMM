#include "tete.h"

/************************************************************************************************/
/*                                                                                              */
/*                                                                                              */
/*                                	   I N T E R F A C E                                        */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/
static const char outputfolder[] = "./outputs";
int promptno =1;

char status[]="ZZ";
char		hypothesisInstruction[500] ;
char     yesReasonsInstruction[500] ;
char      noReasonsInstruction[500] ;
char     botReasonsInstruction[500] ;
char    confoundersInstruction[500] ;
char addconfoundersInstruction[500] ;
char           dataInstruction[500] ; 
char         authorInstruction[500] ;
char     experimentInstruction[500] ;
char         resultInstruction[500] ;


char defaultPublicationPrompt[] = "\tPlease bibliographic reference (or type enter to skip):\nPUBLICATION ";
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/

int promptAndScan(char *prompt, char *text){
	printf("%s",prompt);
	int r=scanf("%[^\n]s\n",text);
	getchar();
	if(!r){*text=' ';}
	return r;
}

int promptAndScanInstruction(char *instruction, char *text, char *sub){
	char prompt[200];
	int n;
	if(strcmp(sub,"")!=0){
		n = promptno;
		promptno++;
	} else{
		n = promptno -1;
	}
	snprintf(prompt,200,"\t(%d%s) %s",n,sub,instruction);
	return promptAndScan(prompt,text);
}

/*
int promptAndScanInstruction(char *instruction, char *text, char *sub){
	printf("\t(%d%s) %s",promptno,sub,instruction);
	int r  = scanf("%[^\n]s\n",text);
	getchar();
	if(!r){
		*text = ' ';
	}
	if(strcmp(sub,"")!=0){
		promptno++;
	}
	return r;
}*/

/*
int promptAndScanSubInstruction(char *prompt, char *text, char *sub){
	printf("\t(%d%s) %s",promptno-1,sub,prompt);
	int r  = scanf("%[^\n]s\n",text);
	getchar();
	if(!r){
		*text = ' ';
	}
	return r;
}*/


int promptAndScanInstructionManditory(char *prompt, char *text){
	printf("\t(%d) %s",promptno,prompt);
	int r = scanf("%[^\n]s\n",text);
	getchar();
	while(!r){
		//printf("\tPlease answer\n");
		r=scanf("%[^\n]s\n",text);
		getchar();
	}
	promptno++;
	return r;
}

int promptAndScanSubInstructionManditory(char *prompt, char *text, char *sub){
	printf("\t(%d%s) %s",promptno-1,sub,prompt);
	int r = scanf("%[^\n]s\n",text);
	getchar();
	while(!r){
		//printf("\tPlease answer\n");
		r=scanf("%[^\n]s\n",text);
		getchar();
	}
	return r;
}

scanYesNo(instruction, promptno-1,"a");

bool scanYesNo(char *instruction, int no,char *sub){
	char prompt[200], answer[]="Z";
	snprintf(prompt,200,"\t(%d%s)%s Please type 'Y' for yes, and 'N' for no.\nSTATUS ",no,sub,instruction);
	promptAndScanInstruction(prompt,answer,"");
	while(strcmp(answer,"Y")!=0 && strcmp(answer,"N")!=0){
		promptAndScan("",answer);
	}
	return strcmp(answer,"Y");
}


char * RemoveSpaces(char source[]){
	static char name[500];
	int len=0;
	int k;
	for(k=0;k<strlen(source);k++){ 
		if(source[k]==' '){
			name[len]='-';
			len ++;
		} else if (ispunct(source[k])>0){ }
		else{
			name[len]=source[k];
			len ++;
		}
	}
	name[len] = '\0';
	return name;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void createFiles(char givenname[], ATOM *q){
	printf("\n----------------------------------------------------------------------------------------------\n");
	int r= mkdir(outputfolder,0777);
	if(errno == EEXIST ){
	} else if(r && errno != EEXIST ){
   	printf("Error while trying to create folder %s! (r=%d) errno = %d\n",outputfolder,r,errno);
	} else{
		printf("Created folder %s\n",outputfolder);
	} 		
	char name[200];
	strcpy(name,RemoveSpaces(givenname));
	//folder
	char folder[200]; errno=0;
	snprintf(folder,200,"%s/%s",outputfolder,name);
	r= mkdir(folder,0777);
	if(errno == EEXIST ){
		printf("Folder %s already exists: overwriting its contents!\n",folder);
	} else if(r && errno != EEXIST ){
   	printf("Error while trying to create folder %s! (r=%d) errno = %d\n",folder,r,errno);
	} else{
		printf("Created folder %s\n",folder);
	} 		
	// Latex
	char filename[200];
	snprintf(filename,200,"%s/%s-Latex.tex",folder,name);
	FILE *fp = fopen(filename,"w+"); 
	if( fp ){
		fprintf(fp,"\\section{%s}\n\n",givenname);
		fprintLatexQUESTION(fp,q);
		fprintf(fp,"\n\n");
		fprintTikzQUESTION(fp,q);
		printf( "Wrote Latex file:\t\t\t %s \n", filename);
	} else 	if(fp == NULL) {
      printf("Error opening file %s! errno = %d\n",filename,errno);   
      exit(1);             
	}
	fclose(fp);
	// Forest
	snprintf(filename,200,"%s/%s-Forest.txt",folder,name);
	fp = fopen(filename,"w+"); 
	if( fp ){
		fprintForestQUESTION(fp,q);
		printf( "Wrote 'tree-like visualisation' file:\t %s \n", filename);
	}
	fclose(fp);
	// Markup
	snprintf(filename,200,"%s/%s-MU.txt",folder,name);
	fp = fopen(filename,"w+"); 
	if( fp ){
		fprintMarkupQUESTION(fp,q);
		printf( "Wrote markup file:\t\t\t %s \n", filename);
	}
	fclose(fp);
	printf("----------------------------------------------------------------------------------------------\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void repeatfprintf(FILE *fp,char *s, int n){
	int i;
	for (i=0;i<n;i++){
		fprintf(fp,"%s",s);
	}
}

void framefprintf(FILE *fp,char *s, int n){
	printf("\t|");
	int i=(n-2-strlen(s))/2;
	repeatfprintf(stdout," ",i);
	printf("%s",s);
	i=n-i-2-strlen(s);
	repeatfprintf(stdout," ",i);
	printf("|\n");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void getLexic(ATOM *a,char *expression, char *sub){
	char term[200], definition[200], prompt[200];
	snprintf(prompt,200,"\t(%d%s) Please list non-obvious terms that you used in %s\t(type enter to skip at any point)\nTERM ",promptno-1,sub,expression);
	//snprintf(prompt,200,"\tLEXIC\n\tTERM ");
	if(promptAndScan(prompt, term)){
		//snprintf(prompt,200,"\tHow do you define '  %s ' ?\t",term);//strcpy(prompt,"How do you define ' ");	strcat(prompt,term);	strcat(prompt," ' ?\t");
		snprintf(prompt,200,"\t:= ");
		if(!promptAndScan(prompt, definition)){
				strcpy(definition,"??");
		}	
		if(!a->context){initCONTEXT(a);}
		recordNewENTRY(a->context->lexic,term,definition);
		//snprintf(prompt,200,"\tWhat other non-obvious terms appear in %s?\t",expression);
		snprintf(prompt,200,"TERM ");
		while(promptAndScan(prompt, term)){
			//snprintf(prompt,200,"\tHow do you define '  %s ' ?\t",term);
			snprintf(prompt,200,"\t:= ");
			if(!promptAndScan(prompt, definition)){
				strcpy(definition,"??");
			}	
			recordNewENTRY(a->context->lexic,term,definition);
			//snprintf(prompt,200,"\tWhat other non-obvious terms appear in %s?\t",expression);
			snprintf(prompt,200,"TERM ");
		}
	}
	if(promptno>2){
		printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
		framefprintf(stdout,"",120);
		framefprintf(stdout,"Rather than have the user register her own new definition for each term or leave the definition blank,",120);
		framefprintf(stdout,"here the interface would make suggestions of definitions for her to choose from.",120);
		framefprintf(stdout,"These suggestions would be taken from the definitions previously given by other users for the same term.",120);
		printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
	}
}

void getReference(ATOM *a, char *prompt){	
	char text[2000],publication[2000],altprompt[200];
	snprintf(altprompt,200,"\t(%db) %s",promptno-1,prompt);
	if(promptAndScan(altprompt, publication)){
		if(!a->context){initCONTEXT(a);}
		snprintf(text,200,"Published in %s\t<FLAG:PUBLICATION>",publication); 
		recordNewATOM(a->context->statements,text);
	}
}

void getReferenceInstruction(ATOM *a, char *instruction){	
	char prompt[2000], text[2000],publication[2000];
	snprintf(prompt,200,"\t(%d) %s\nPUBLICATION ",promptno,instruction);
	if(promptAndScan(prompt, publication)){
		snprintf(text,200,"Published in %s\t<FLAG:PUBLICATION>",publication); 
		//if(!a->context){printf("ok here??\n"); initCONTEXT(a);}
		recordNewATOM(a->context->statements,text);
	}
	promptno++;
}

void getReasons(CONTEXT * c, char *instruction, char *subinstruction){
	char text[1000],othertext[1000];
	if(promptAndScanInstruction(instruction,othertext,"")){ 
		snprintf(text,200,"%s\t<FLAG:UPSTREAM>",othertext); 
		recordNewATOM(c->statements,text);
		getLexic(c->statements->list[c->statements->count-1],"your wording of this reason","a");
		getReference(c->statements->list[c->statements->count-1], defaultPublicationPrompt);
		promptno = promptno-1;
		while(promptAndScanInstruction(subinstruction,othertext,"")){
			snprintf(text,200,"%s\t<FLAG:UPSTREAM> ",othertext); 
			recordNewATOM(c->statements,text);
			getLexic(c->statements->list[c->statements->count-1],"your wording of this reason","a");
			getReference(c->statements->list[c->statements->count-1], defaultPublicationPrompt);
			promptno = promptno-1;
		}
	}
	printNBReason();
}

void getConfounders(ATOM *experiment){
	char text[1000],othertext[1000],addressed[10];
	while(promptAndScanInstruction(confoundersInstruction,othertext,"")){
	if(scanYesNoSub(addconfoundersInstruction,addressed,"a"))		

	//promptAndScanSubInstructionManditory(addconfoundersInstruction,addressed,"a");
		if(strcmp(addressed,"Y")==0){
			snprintf(text,200,"%s But this issue has been addressed.\t<FLAG:CONFOUNDER TYPE 1>",othertext); 
			recordNewATOM(experiment->context->statements, text);
			ATOM *confounder = experiment->context->statements->list[experiment->context->statements->count-1];
			initCONTEXT(confounder);
			if(promptAndScanSubInstruction("How? Please describe your experiment.\nEXPERIMENT ",othertext,"b")){
				snprintf(text,200,"%s\t<FLAG:EXPERIMENT>",othertext); 
				recordNewATOM(confounder->context->statements, text);
				ATOM *subexperiment = confounder->context->statements->list[confounder->context->statements->count-1];
				initCONTEXT(subexperiment);
				getLexic(subexperiment,"your descripion of your experiment","b.a");	
			} else{
				recordNewATOM(confounder->context->statements, "Missing experiment description.\t<FLAG:EXPERIMENT>");
			}
			promptno = promptno-1 ;
		}
		if(strcmp(addressed,"N")==0){
			snprintf(text,200,"%s But this is assumed not to happen.\t<FLAG:CONFOUNDER TYPE 2>",othertext); 
			recordNewATOM(experiment->context->statements, text);	
			promptno = promptno-1 ;
		}
	}
	//promptno++;
	recordNewATOM(experiment->context->statements, "Some unforseen thing could go wrong. But this is assumed not to happen.\t<FLAG:CONFOUNDER TYPE 2>");
}

ATOM *getExperiment(){
	char text[1000],othertext[1000];
	ATOM *experiment;
	if(!promptAndScanInstruction(experimentInstruction,othertext,"")){ 
		strcpy(text,"Missing experiment description.\t<FLAG:EXPERIMENT> ");
		experiment = initATOM(text,"Statement",5);
		initCONTEXT(experiment);
	} else {
		snprintf(text,200,"%s\t<FLAG:EXPERIMENT>",othertext);
		experiment = initATOM(text,"Statement",5);
		initCONTEXT(experiment);
		getLexic(experiment,"your descripion of your experiment","a");	//detailed explanation of certain jargon, experiment techniques or procedures , by referring to protocol document or other studies
	}
	getConfounders(experiment); //confoundersInstruction,addconfoundersInstruction
	// Data --------------------------------------------------------------------------------------
	if(promptAndScanInstruction(dataInstruction,othertext,"")){
		snprintf(text,200,"%s\t<FLAG:DATA>",othertext);
		recordNewATOM(experiment->context->statements,text);
	}
	return experiment;
}

ATOM *getArgument(ATOM *answer, char *author){
	char text[1000],othertext[1000];
	ATOM *argument;
	if(!promptAndScanInstruction(resultInstruction,othertext,"")){
		snprintf(text,200,"Some unspecified argument in favour of the answer being ' %s ' actually being proven experimentally by %s.",answer->text, author);
		recordNewATOM(answer->context->statements,text); 
		argument = answer->context->statements->list[answer->context->statements->count-1];
		initCONTEXT(argument);
	} else{
		snprintf(text,200,"Efforts are being made to prove that %s : an experiment is currently being carried out by %s.",othertext,author);
		recordNewATOM(answer->context->statements, text); 
		argument = answer->context->statements->list[answer->context->statements->count-1];
		initCONTEXT(argument);
		getLexic(argument,"what you wrote","a");
		getReferenceInstruction(argument, "Have you published your results (so far)? If so, enter reference of publication.");
	}
	return argument;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void printNBHypothesis(){
	printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
	framefprintf(stdout,"",120);
	framefprintf(stdout,"Here, the interface would ask the user if her working hypothesis is the same as",120);
	framefprintf(stdout,"similar ones previously recorded in the MMM by other users, assuming any similar ones are found.",120);
	printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
}

void printNBReason(){
	printf("\t");repeatfprintf(stdout,"_",120);printf("\n");
	framefprintf(stdout,"",120);
	framefprintf(stdout,"Here, instead of typing statements expressing the reasons she is prompted to give,",120);
	framefprintf(stdout,"the user could also select statements already registered in the MMM.",120);
	framefprintf(stdout,"If preregistered statements are almost yet not exactly what the user wants to register,",120);
	framefprintf(stdout,"she is given the opportunity to explicit the relationship/difference between",120);
	framefprintf(stdout,"her newly registered statement and preregistered ones.",120);
	printf("\t|");repeatfprintf(stdout,"_",118);printf("|\n\n");
}
/************************************************************************************************/
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/*                                                                                              */
/************************************************************************************************/

ATOM * registerStudy(){
	// Question -- Please frame your working hypothesis -------------------------------------------
	char text[2000], othertext[2000],author[200]; 
	promptAndScanInstructionManditory(hypothesisInstruction, othertext,"");
	printNBHypothesis();
	snprintf(text,2000,"Is it true that ' %s ' ?",othertext); 
	ATOM* q = initATOM(text,"question",0);
	initCONTEXT(q);
	getLexic(q,"your wording of your working hypothesis","a"); //add  definitions to help other people understand your research question;
	q->answers=initATOMS(q->depth+1,"answers");
	// Yes answer ---------------------------------------------------------------------------------
	recordNewATOM(q->answers, "Yes.");
	ATOM *yes = q->answers->list[q->answers->count-1];
	initCONTEXT(yes);
	getReasons(yes->context,yesReasonsInstruction,"What reasons presently supports your working hypothesis?\nREASON FOR ");
	// No answer ----------------------------------------------------------------------------------
	recordNewATOM(q->answers, "No.");
	ATOM *no = q->answers->list[q->answers->count-1];
	initCONTEXT(no);
	getReasons(no->context,noReasonsInstruction,"What reasons disagree/oppose/negate your working hypothesis?\nREASON AGAINST ");
	// Absurd answer ------------------------------------------------------------------------------
	recordNewATOM(q->answers, "The question doesn't make sense or is irrelevant.");
	ATOM *absurd = q->answers->list[q->answers->count-1];
	initCONTEXT(absurd);
	getReasons(absurd->context,botReasonsInstruction,"What could make you working hypothesis irrelevant?\nREASON ");
	// Experiment and result ----------------------------------------------------------------------
	ATOM *experiment = getExperiment();
	promptAndScanInstruction(authorInstruction,author,"");
	ATOM *result = getArgument(yes, author);
	result->context->statements->list[result->context->statements->count] = experiment;
	result->context->statements->count++;	
	return q;
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
ATOM * closeStudy(){ 
	char text[2000],success[100];
	promptAndScanInstruction("Have you proven your working hypothesis? Please type 'Y' for yes, and 'N' for no.\nSTATUS ",success,"");
		

		promptAndScanInstruction("Have you proven your working hypothesis? Please type 'Y' for yes, and 'N' for no.\nSTATUS ",success,"");
		while(strcmp(success,"Y")!=0 && strcmp(success,"N")!=0){
			promptAndScan("", success);
		}
		if(strcmp(success,"Y")==0){
			int r=promptAndScanInstruction("What is the conclusion of your study supporting your working hypothesis?\nCONCLUSION ", text,"");
		}
		if(strcmp(success,"N")==0){
			printf("\tThis case has to be dealt with.\n");
		}

	return NULL;
	// ask for markup file and scan 
	// name
	// frame nb here the user would actually select a MMM unit registered before.
	// or not: start form scratch
	// Ask if WH was successful or not
	// If not, ask if they still believe its true or if smth went wrong or both
	// Ask if they still believe WH makes sense.
	// if success 
	// if failure but still believe
	// if failure but wrong
	// if failure and don't know
	// if absurd
	// create new question. free old one.rename old file.
	/*
char *removeExtension(char* mystr) {
    char *retstr;
    char *lastdot;
    if (mystr == NULL)
         return NULL;
    if ((retstr = malloc (strlen (mystr) + 1)) == NULL)
        return NULL;
    strcpy (retstr, mystr);
    lastdot = strrchr (retstr, '.');
    if (lastdot != NULL)
        *lastdot = '\0';
    return retstr;
}

*/
	// snprintf(othername,200,"%sOld.txt",removeExtension(name)); int rename(name, othername); printf("Renamed file %s to %s\n",othername,name);
	// remove folder names at begin of other name
	// createfiles(othername, newq);
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
void setInstructionsP(){
	strcpy(    hypothesisInstruction, "What is your working hypothesis?\nHYPOTHESIS ");
	strcpy(    yesReasonsInstruction, "What reasons presently supports your working hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be motivations, statements drawn from the state of the art of your field and/or from logical inferences.\nREASON FOR ");
	strcpy(     noReasonsInstruction, "To your present knowledge are there reasons to expect your working hypothesis might not be true?\n\t    Please list one reason at a time.\n\t    Reasons can be negative results, facts or statements drawn from the state of the art of your field and/or from logical inferences, that disagree/oppose/negate your working hypothesis.\nREASON AGAINST ");
	strcpy(    botReasonsInstruction, "Are there reasons to expect your working hypothesis might be irrelevant or absurd?\n\t    Please list one reason at a time.\n\t    Reasons can be ambiguity in the wording of the hypothesis, uncertainty in the meaning of certain terms it involves, etc.\nREASON ");
	strcpy(   confoundersInstruction, "What might confound or undermine your study?\n\t    What could go wrong in your experiment?\n\t    Please list all possibilities you can think of.\nCONFOUNDER/LIMIT ");
	strcpy(addconfoundersInstruction, "Have you addressed this confounder? Have you checked it couldn't go wrong?\n\t    Type 'Y' for Yes and 'N' for No.\nSTATUS ");
	strcpy(          dataInstruction, "What are your results so far? Please register/upload your (meta)data and your interpretation of it.\t /!\\TODO/!\\ \nDATA "); // & METADATA!
	strcpy(        authorInstruction, "Please name the individual(s), team(s) and/or institution(s) actively involved in performing this study\nAUTHOR ");
	strcpy(    experimentInstruction, "Please describe your experiment/study (eg: experiment design and main methods).\nEXPERIMENT ");// brief yet sufficient description of the study
	strcpy(        resultInstruction, "If this experiment is successful what will it show that supports your working hypothesis?\nINTERPRETATION/CONCLUSION ");
}
void setInstructionsS(){
	strcpy(    hypothesisInstruction, "What is your working hypothesis?\nHYPOTHESIS ");
	strcpy(    yesReasonsInstruction, "What reasons presently supports your working hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be motivations, statements drawn from the state of the art of your field and/or from logical inferences.\nREASON FOR ");
	strcpy(     noReasonsInstruction, "To your present knowledge are there reasons to expect your working hypothesis might not be true?\n\t    Please list one reason at a time.\n\t    Reasons can be negative results, facts or statements drawn from the state of the art of your field and/or from logical inferences, that disagree/oppose/negate your working hypothesis.\nREASON AGAINST ");
	strcpy(    botReasonsInstruction, "Are there reasons to expect your working hypothesis might be irrelevant or absurd?\n\t    Please list one reason at a time.\n\t    Reasons can be ambiguity in the wording of the hypothesis, uncertainty in the meaning of certain terms it involves, etc.\nREASON ");
	strcpy(   confoundersInstruction, "What might confound or undermine your study?\n\t    What could go wrong in your experiment?\n\t    Please list all possibilities you can think of.\nCONFOUNDER/LIMIT ");
	strcpy(addconfoundersInstruction, "Can you address this confounder? Can you check it can't go wrong?\n\t    Type 'Y' for Yes and 'N' for No.\nSTATUS ");
	strcpy(          dataInstruction, "What are your results (so far)? Please register/upload your (meta)data and your interpretation of it.\t /!\\TODO/!\\ \nDATA "); // & METADATA!
	strcpy(        authorInstruction, "Please name the individual(s), team(s) and/or institution(s) actively involved in performing this study\nAUTHOR ");
	strcpy(    experimentInstruction, "Please describe the experiment/study you plan to carry out (eg: experiment design and main methods).\nEXPERIMENT ");// brief yet sufficient description of the study
	strcpy(        resultInstruction, "If this experiment is successful what will it show that supports your working hypothesis?\nINTERPRETATION/CONCLUSION ");
}
void setInstructionsF(){
	strcpy(    hypothesisInstruction, "What was the working hypothesis of your study?\nHYPOTHESIS ");
	strcpy(    yesReasonsInstruction, "Outside of your study, what reasons support this hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be motivations, statements drawn from the state of the art of your field and/or from logical inferences.\nREASON FOR ");
	strcpy(     noReasonsInstruction, "What reasons outside of your study go against the hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be negative results, facts or statements drawn from the state of the art of your field and/or from logical inferences, that disagree/oppose/negate your working hypothesis.\nREASON AGAINST ");
	strcpy(    botReasonsInstruction, "Are there reasons the hypothesis might actually be irrelevant or absurd worded as it is?\n\t    Please list one reason at a time.\n\t    Reasons can be ambiguity in the wording of the hypothesis, uncertainty in the meaning of certain terms it involves, etc.\nREASON ");
	strcpy(   confoundersInstruction, "What might have confounded or undermined your study?\n\t    What might have gone wrong in your experiment?\n\t    Please list all possibilities you can think of.\nCONFOUNDER/LIMIT ");
	strcpy(addconfoundersInstruction, "Have you addressed this confounder? Have you checked it couldn't go wrong?\n\t    Type 'Y' for Yes and 'N' for No.\nSTATUS ");
	strcpy(          dataInstruction, "What are your results? Please register/upload your (meta)data and your interpretation of it.\t /!\\TODO/!\\ \nDATA "); // & METADATA!
	strcpy(        authorInstruction, "Please name the individual(s), team(s) and/or institution(s) actively involved in performing this study\nAUTHOR ");
	strcpy(    experimentInstruction, "Please describe the experiment/study you did (eg: experiment design and main methods).\nEXPERIMENT ");// brief yet sufficient description of the study
	strcpy(        resultInstruction, "What was the conclusion you expected to derive in support of the working hypothesis?\nINTERPRETATION/CONCLUSION ");
}
/************************************************************************************************/
/*                                                                                              */
/************************************************************************************************/
ATOM * neuroscience_mmm(){
	promptno = 0;
	promptAndScanInstruction("Do you want to register a study that is...\n\t    ... not started --> type 'S',\n\t    ...  in process --> type 'P',\n\t    ...    finished --> type 'F'\nSTATUS ", status,"");
	while(strcmp(status,"S")!=0 && strcmp(status,"P")!=0 && strcmp(status,"F")!=0){
		promptAndScan("", status);
	}
	printf("\tOk.\tNow...\n\n");
	if(strcmp(status,"P")==0){
		setInstructionsP();
		return registerStudy();
	} 	else if(strcmp(status,"S")==0 ){
		setInstructionsS();
		return registerStudy();
	} else if (strcmp(status,"F")==0){
		setInstructionsF();
		ATOM *q = registerStudy(); 
		return closeStudy();
	} 
	return NULL;
}


/*
char     yesReasonsInstruction[] = "What reasons presently supports your working hypothesis?\n\t    Please list one reason at a time.\n\t    Reasons can be motivations, statements drawn from the state of the art of your field and/or from logical inferences.\nREASON FOR ";
char      noReasonsInstruction[] = "To your present knowledge are there reasons to expect your working hypothesis might not be true?\n\t    Please list one reason at a time.\n\t    Reasons can be negative results, facts or statements drawn from the state of the art of your field and/or from logical inferences, that disagree/oppose/negate your working hypothesis.\nREASON AGAINST ";
char     botReasonsInstruction[] = "Are there reasons to expect your working hypothesis might be irrelevant or absurd?\n\t    Please list one reason at a time.\n\t    Reasons can be ambiguity in the wording of the hypothesis, uncertainty in the meaning of certain terms it involves, etc.\nREASON ";
char    confoundersInstruction[] = "What might confound or undermine your study?\n\t    What could go wrong in your experiment?\n\t    Please list all possibilities you can think of.\nCONFOUNDER/LIMIT ";
char addconfoundersInstruction[] = "Have you addressed this confounder? Have you checked it couldn't go wrong?\n\t    Type 'Y' for Yes and 'N' for No.\nSTATUS ";
char           dataInstruction[] = "What are your results (so far)? Please register/upload your (meta)data and your interpretation of it.\t /!\\TODO/!\\ \nDATA "; // & METADATA!
char         authorInstruction[] = "Please name the individual(s), team(s) and/or institution(s) actively involved in performing this study\nAUTHOR ";
char     experimentInstruction[] = "Please describe your experiment/study (eg: experiment design and main methods).\nEXPERIMENT ";// brief yet sufficient description of the study
char         resultInstruction[] = "If this experiment is successful what will it show that supports your working hypothesis?\nINTERPRETATION/CONCLUSION ";
*/
